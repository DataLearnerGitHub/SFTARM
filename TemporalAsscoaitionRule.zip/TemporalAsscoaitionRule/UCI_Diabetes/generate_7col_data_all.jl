using JLD2
include("cossqr.jl")

@load "data_all_xVal.jld2" data_all xVal
v_cs = xVal[1:70]
v_τ33 = (xVal[71], xVal[72], xVal[73])
v_τ34 = (xVal[74], xVal[75], xVal[76])
v_τ35 = (xVal[77], xVal[78], xVal[79])
v_τ = Dict(33 => v_τ33, 34 => v_τ34, 35 => v_τ35)
ItemType = Tuple{
    Float64,
    Dict{Int32,Tuple{Float64,Float64}},
    Dict{Int32,Tuple{Float64,Float64}},
}
function value_fuzzy(item::Tuple{Float64,Dict{Int32,Tuple{Float64,Float64}},Dict{Int32,Tuple{Float64,Float64}}}, isCurrent::Bool, code::Int64)
    diffT = item[if isCurrent
        3
    else
        2
    end][code][1]
    value_membership = 4.0
    (refT, actValue) = item[if isCurrent
        3
    else
        2
    end][code]
    if diffT <= 2.0
        value_membership = 1.0
    elseif diffT <= 6.0
        value_membership = 2.0  - (diffT - 2.0) / 4.0
    elseif diffT <= 12.0
        value_membership = 3.0  - (diffT - 6.0) / 10.0
    elseif diffT <= 24.0
        value_membership = 4.0  - (diffT - 12.0) / 12.0
    else
        value_membership = 4.0
    end
    value_membership
end
function colValue(
    item::ItemType,
    i_c::Int,
    code::Int,
    isCurrent::Bool,
    v_cs::Array{Float64,1},
    v_τ::Dict{Int64,Tuple{Float64,Float64,Float64}},
)
    t = item[if isCurrent
        3
    else
        2
    end][code][1]
    v_c = v_cs[i_c]
    CosSqr.value(t, v_c, v_τ[code])
end

function getRow(
    item::ItemType,
    i_c::Int,
    v_cs::Array{Float64,1},
    v_τ::Dict{Int64,Tuple{Float64,Float64,Float64}},
)
    (
     item[1],
     colValue(item, i_c, 33, true, v_cs, v_τ),
     colValue(item, i_c, 34, true, v_cs, v_τ),
     colValue(item, i_c, 35, true, v_cs, v_τ),
     colValue(item, i_c, 33, false, v_cs, v_τ),
     colValue(item, i_c, 34, false, v_cs, v_τ),
     colValue(item, i_c, 35, false, v_cs, v_τ),
     value_fuzzy(item, true, 65),
     value_fuzzy(item, true, 66),
     value_fuzzy(item, true, 67),
     value_fuzzy(item, true, 68),
     value_fuzzy(item, true, 69),
     value_fuzzy(item, true, 70),
     value_fuzzy(item, true, 71),
     value_fuzzy(item, true, 72),
     value_fuzzy(item, false, 65),
     value_fuzzy(item, false, 66),
     value_fuzzy(item, false, 67),
     value_fuzzy(item, false, 68),
     value_fuzzy(item, false, 69),
     value_fuzzy(item, false, 70),
     value_fuzzy(item, false, 71),
     value_fuzzy(item, false, 72),

    )
end

function getTable(
    data::Array{Any,1},
    v_cs::Array{Float64,1},
    v_τ::Dict{Int64,Tuple{Float64,Float64,Float64}},
)
    result = []
    for (i_c, record) in enumerate(data_all)
        for item in record
            push!(result, getRow(item, i_c, v_cs, v_τ))
        end
    end
    result = (("bgLevel", "curr33", "curr34", "curr35", "prev33", "prev34", "prev35",
    "curr65", "curr66", "curr67","curr68", "curr69", "curr70","curr71", "curr72",
    "prev65", "prev66", "prev67","prev68", "prev69", "prev70","prev71", "prev72",
    ),
        result)
end

result = getTable(data_all, v_cs, v_τ)
@save "transactions_fuzzy.jld2" result
