include("ucid.jl")

include("cossqr.jl")
include("igfactor.jl")
#include("process.jl")
include("generateTransactions_timeParameters_params.jl")
include("generateRulesDerivative_comparisons.jl")
