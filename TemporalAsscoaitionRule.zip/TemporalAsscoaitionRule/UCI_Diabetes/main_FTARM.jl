 include("ucid.jl")
include("cossqr.jl")
include("igfactor.jl")
include("process.jl")
#include("apriori.jl")
using Dates
using JuMP
using Ipopt
using JLD2

# raw data from uci diabetes
#rawData = UCID.loadUCIDiabetes("/Users/hui/Downloads/Temporal_Asscoaition_rule/")
#path= "D:/zh/Temporal_Asscoaition_rule"
path = "/Users/hui/work/Programs/TemporalAsscoaitionRule20200723/"
rawData = UCID.loadUCIDiabetes(path)
# io = open(path*"002.log", "w")
# variables and symbols for duration scaling
knownCode = [33, 34, 35]
#rawData = normalization(io)
#println(io, "rawData = $rawData")
#exit()
nData = size(rawData, 1)
nX = nData + size(knownCode, 1) * 3
varOffset = Dict(33 => nData, 34 => nData + 3, 35 => nData + 6)
model = Model(with_optimizer(
    Ipopt.Optimizer,
    max_iter = 2,
    adaptive_mu_globalization = "never-monotone-mode",
))
τ33_init = [0.5, 2.5, 7.5]
τ34_init = [2, 7, 19]
τ35_init = [3.5, 4, 31]
function x0(i)
    if i <= nData
        1.0
    elseif i <= nData + 3
        τ33_init[i-nData]
    elseif i <= nData + 6
        τ34_init[i-nData-3]
    else
        τ35_init[i-nData-6]
    end
end
@variable(model, x[i = 1:nX] >= 0.001, start = x0(i))
for i = 1:nData
    @constraint(model, x[i] <= 3.0)
end
for code in knownCode
    @constraint(model, x[varOffset[code]+1] + 0.001 <= x[varOffset[code]+2])
    @constraint(model, x[varOffset[code]+2] + 0.001 <= x[varOffset[code]+3])
    @constraint(model, x[varOffset[code]+3] <= 2.0 * x0(varOffset[code] + 3))
end
@constraint(model, sum(x[1:nData]) == nData)
# convert DateTime into propority of hours
function tToDiffT(t::DateTime, act::Dict{Int32,Tuple{DateTime,Float64}})
    result = Dict{Int32,Tuple{Float64,Float64}}()
    for code in keys(act)
        (refT, actValue) = act[code]
        @assert t >= refT
        diffT = (t - refT) / Millisecond(Hour(1))
        result[code] = (diffT, actValue)
    end
    result
end

# define a fuzzified blood glucose levels:
function bgLevel(x::Float64)
    if 40.0 <= x < 80.0
        2.0 - (80.0 - x) / 40.0
    elseif 80.0 <= x < 130.0
        2.0
    elseif 130.0 <= x < 300.0
        3.0 - (300.0 - x) / 170.0
    elseif x >= 300.0
        3.0
    else
        1.0
    end
end

# convert data record to diffT
function recordToDiffT(record::Array{UCID.Activity,1})
    result = []
    dateTime0 = DateTime("1-1-0 0:0", "m-d-y H:M")
    nilActStat = (dateTime0, 0.0)
    prevAct = Dict{Int32,Tuple{DateTime,Float64}}(
        33 => nilActStat,
        34 => nilActStat,
        35 => nilActStat,
    )
    currAct = Dict{Int32,Tuple{DateTime,Float64}}(
        33 => nilActStat,
        34 => nilActStat,
        35 => nilActStat,
    )
    for act in record
        if act.code in keys(currAct)
            prevAct[act.code] = currAct[act.code]
            currAct[act.code] = (act.dateTime, act.value)
        elseif 48 <= act.code <= 64
            push!(
                result,
                (
                 bgLevel(act.value),
                 tToDiffT(act.dateTime, prevAct),
                 tToDiffT(act.dateTime, currAct),
                ),
            )
        end
    end
    result
end

data = []
for record in rawData
    push!(data, recordToDiffT(record))
end

function f(xVal...)
    inputs = []
    global knownCode, varOffset
    for (k, record) in enumerate(data)
        for (bg, prevAct, currAct) in record
            valueArray = Array{Float64,1}()
            for code in knownCode
                for diffT in [prevAct[code][1], currAct[code][1]]
                    value = CosSqr.value(
                        diffT,
                        xVal[k],
                        xVal[ varOffset[code].+(1:3)],
                    )
                    push!(valueArray, value)
                end
            end
            push!(inputs, IGFactor.InputValue(bg, valueArray))
        end
    end
    IGFactor.value(inputs)
end

function ∇f!(g, xVal...)
    inputs = []
    global knownCode, varOffset, x
    for (k, record) in enumerate(data)
        for (bg, prevAct, currAct) in record
            dwrtArray = Array{IGFactor.EvalDict,1}()
            for code in knownCode
                for diffT in [prevAct[code][1], currAct[code][1]]
                    dwrt = CosSqr.dwrt(
                        diffT,
                        x[k],
                        x[varOffset[code].+(1:3)],
                        xVal[k],
                        xVal[varOffset[code].+(1:3)],
                    )
                    push!(dwrtArray, dwrt)
                end
            end
            push!(inputs, IGFactor.InputDwrt(bg, dwrtArray))
        end
    end
    dwrt = IGFactor.dwrt(inputs)
    for (iX, varX) in enumerate(x)
        g[iX] = get(dwrt, varX, 0.0)
    end
end


JuMP.register(model, :f, nX, f, ∇f!)
@NLobjective(model, Max, f(x...))
# @load "x.jld2" x
optimize!(model)
# println(io, "------------------Optimization results-------------------")
# for (iX, varX) in enumerate(x)
#     println(io, "x[$iX]=", value(varX))
# end

# println(io, "--------------Normalization--------------")
#rawData = normalization(io)
#generate_candidature(x, 0.1)
#println(io, "---------------Generate frequent items------------------")

xVal = fill(0.0, length(x))
for i in 1:length(x)
    xVal[i] = value(x[i])
end
@save "001_FTARM.jld2" data xVal
# include("generate_7col_data.jl")
# include("apriori.jl")
# println(io, "-----------------generate TARules----------------")
# freqSetList = Apriori(result, 0.1)
# generate_TARules(io,freqSetList, 0.6)
#close(io)
