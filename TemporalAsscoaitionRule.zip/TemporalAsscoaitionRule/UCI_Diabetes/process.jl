include("ucid.jl")
#using Dates
# raw data from uci diabetes
function normalization(io)
#path= "/Users/hui/Downloads/Temporal_Asscoaition_rule/"
#rawData = UCID.loadUCIDiabetes(path)
#io = open(path*"002.log", "w")
for (k, record) in enumerate(rawData)
    for code in [33,34,35,48,57,58,59,60,61,62,63,64]
        sum_value = 0.0
        sum_number = 0
        for record_index in record
            if record_index.code == code
                sum_value += record_index.value
                sum_number += 1
            end
        end
        if sum_number > 0 && sum_value > 0
            sum_value_avg = sum_value / sum_number
            for record_index in record
                if record_index.code == code
                    record_index.value /= sum_value_avg
                end
            end
        end
        println(
            io,
            "The $k record--- sum_value_$code = $sum_value, sum_number_$code = $sum_number",
        )
    end
end
#close(io)
rawData
end
function maximum_code(io)
    for code in knownCode
        code_minimum = 10000.0
        code_maximum = -1.0
        for (k, record) in enumerate(rawData)
            for record_index in record
                if record_index.code == code && record_index.value > code_maximum
                    code_maximum = record_index.value
                end
                if record_index.code == code && record_index.value < code_minimum
                    code_minimum = record_index.value
                end
            end
        end
        println(
            io,
            "code_maximum_$code = $code_maximum, code_minimum_$code = $code_minimum",
        )
    end
end
function frequent_item_sets()
    println("generating frequent_item_sets")
end
