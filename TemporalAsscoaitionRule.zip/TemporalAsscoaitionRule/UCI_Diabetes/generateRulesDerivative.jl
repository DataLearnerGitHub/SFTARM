using JLD2
include("aprioriDerivative.jl")

# original functions
path = "/Users/hui/work/Programs/TemporalAsscoaitionRule20200901/Results/"
function generate_TARules(comparisonFilteredOutputRules,freqSetList, minSupp, minConf)
    count_outputed_rules = 0
    AvgSupport = 0.0
    AvgConfidence = 0.0
    AvgLift = 0.0
    # count_rules_specials = 0
    #count_outputed_abnormal = 0
    Rules = []
    for i = length(freqSetList):-1:5
        #println("i=",i)
        for (key, val) in freqSetList[i]
            consequent = []
            for freqItem in key
                if freqItem[1] == "bgLevel" || freqItem[1] == "prevBgLevel" || freqItem[1] == "DcurrBgLevel"|| freqItem[1] == "DprevBgLevel"
                    push!(consequent, freqItem)
                end
            end
            # println(length(consequent))
            if length(consequent) == 0
                continue
            end
            numConsequent = length(consequent)
            antecedent = setdiff(key, consequent)
            support_of_antecedent = freqSetList[i-numConsequent][antecedent]
            support_of_consequent = freqSetList[numConsequent][Set{Tuple{String,Int64}}(consequent)]
            Confidence_current = val / support_of_antecedent
            Lift_current = val / support_of_consequent

            #println("$(support_of_antecedent), $(Confidence_current), $(antecedent), $(consequent)")

            if Confidence_current >= minConf
                count_outputed_rules = count_outputed_rules + 1
                AvgSupport = AvgSupport + val
                AvgConfidence = AvgConfidence + Confidence_current
                AvgLift = AvgLift + Lift_current
                # if consequent == Any[("bgLevel", 2)] || consequent == Any[("prevBgLevel", 2)] || consequent == Any[("bgLevel", 2), ("prevBgLevel", 2)] || consequent == Any[("prevBgLevel", 2), ("bgLevel", 2)]
                #     continue
                # end

                # if consequent != Any[("bgLevel", 2), ("prevBgLevel", 2)] && consequent != Any[("prevBgLevel", 2), ("bgLevel", 2)]
                #     count_outputed_abnormal += 1
                # end
                push!(Rules, (count_outputed_rules, val, Confidence_current, Lift_current, antecedent, consequent))
                # println(
                #     io,
                #     (
                #      "outputed_rules",
                #      count_outputed_rules,
                #      ": Support =",
                #      val,
                #      " Confidence=",
                #      Confidence_current,
                #      " Lift =",
                #      Lift_current,
                #      "    antecedent=",
                #      antecedent,
                #      "--->> consequent=",
                #      consequent,
                #     ),
                # )
                # println(outputRules, "$(count_outputed_rules), $(val), $(Confidence_current), $(Lift_current), $(antecedent)=>$(consequent)")
                # println(outputRules, replace(
                #     replace(
                #         "$(count_outputed_rules), $(val), $(Confidence_current), $(Lift_current), $(antecedent)=>$(consequent)",
                #         "Set(Tuple{String,Int64}" => "("
                #     ),
                #     "Any" => ""
                # ))
            end

        end
    end
    #  println(
    # #     "count_outputed_abnormal=",
    # #     count_outputed_abnormal,
    #      "    count_outputed_rules=",
    #      count_outputed_rules,
    #  )
    #close(io)
    #close(outputRules)
    @save path*"RULES_$(minSupp)_$(minConf).jld2" Rules

    if count_outputed_rules == 0
        AvgSupport = 0.0
        AvgConfidence = 0.0
        AvgLift = 0.0
    else
        AvgSupport = AvgSupport / count_outputed_rules
        AvgConfidence = AvgConfidence / count_outputed_rules
        AvgLift = AvgLift / count_outputed_rules
    end
    println(comparisonFilteredOutputRules, "outputRules: count_outputed_rules=$count_outputed_rules, AvgSupport = $AvgSupport, AvgConfidence = $AvgConfidence, AvgLift = $AvgLift")
    println("outputRules: count_outputed_rules=$count_outputed_rules, AvgSupport = $AvgSupport, AvgConfidence = $AvgConfidence, AvgLift = $AvgLift")
    count_outputed_rules
end

# Further filtering Rules
function filterRules(comparisonFilteredOutputRules, minSupp, minConf)
    NumberOfFilteredRules = 0
    AvgSupport = 0.0
    AvgConfidence = 0.0
    AvgLift = 0.0
    @load path*"RULES_$(minSupp)_$(minConf).jld2" Rules
    FilteredOutputRules = open(path*"FilteredOutputRules_$(minSupp)_$(minConf).txt", "w")
    println(
        FilteredOutputRules,
        "Order_outputed_rules, Support, Confidence, Lift, Rules",
    )
    FilteredRules = []
    for IRules = 1:length(Rules)
        itemsWith04 = []
        for item in Rules[IRules][5]
            if item[2] == 4 || item[2] == 0
                push!(itemsWith04, item)
            end
        end
        if length(Rules[IRules][5]) == length(itemsWith04)
            continue
        end
        consequent = Rules[IRules][6]
        if consequent == Any[("bgLevel", 2)] ||
           consequent == Any[("prevBgLevel", 2)] ||
           consequent == Any[("bgLevel", 2), ("prevBgLevel", 2)] ||
           consequent == Any[("prevBgLevel", 2), ("bgLevel", 2)]
            continue
        end
        push!(FilteredRules, Rules[IRules])
        NumberOfFilteredRules = NumberOfFilteredRules + 1
        AvgSupport = AvgSupport + Rules[IRules][2]
        AvgConfidence = AvgConfidence + Rules[IRules][3]
        AvgLift = AvgLift + Rules[IRules][4]
        println(
            FilteredOutputRules,
            "$(Rules[IRules][1]):: $(Rules[IRules][2]), $(Rules[IRules][3]), $(Rules[IRules][4]), $(Rules[IRules][5]) ==> $(Rules[IRules][6])",
        )
    end
    #println("saving filtered rules")
    @save path*"FilteredRules" FilteredRules
    #println("filtered rules saved")
    close(FilteredOutputRules)
    if NumberOfFilteredRules == 0
        AvgSupport = 0.0
        AvgConfidence = 0.0
        AvgLift = 0.0
    else
        AvgSupport = AvgSupport / NumberOfFilteredRules
        AvgConfidence = AvgConfidence / NumberOfFilteredRules
        AvgLift = AvgLift / NumberOfFilteredRules
    end
    println(comparisonFilteredOutputRules, "FilteredRules: NumberOfFilteredRules=$NumberOfFilteredRules, AvgSupport = $AvgSupport, AvgConfidence = $AvgConfidence, AvgLift = $AvgLift")
    println("FilteredRules: NumberOfFilteredRules=$NumberOfFilteredRules, AvgSupport = $AvgSupport, AvgConfidence = $AvgConfidence, AvgLift = $AvgLift")
    #NumberOfFilteredRules
    AvgConfidence
end


#close(comparisonFilteredOutputRules)
#freqSetList = Apriori(result, minSupp)
#TARules = generate_TARules(freqSetList, 0.6)
#@save "freqSetListDerivative.jld2" freqSetList

#generate_TARules(freqSetList, minConf)
