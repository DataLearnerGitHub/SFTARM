using JLD2
include("cossqr.jl")
#@load "data_preprocessing.jld2" dataTransactions xVal
#@load "Results/data_preprocessing_test.jld2" dataTransactions xVal
#@load "Results/data_preprocessing_M10I5.jld2" dataTransactions xVal
#@load "data_preprocessing_FTARM.jld2" dataTransactions xVal
@load "Results/test202101/data_preprocessing_FTARM_M.jld2" dataTransactions xVal
#@load "data_preprocessing_FTARM_M.jld2" dataTransactions xVal
#xVal = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.5786959410627814, 3.791220465237668, 7.584610426817192, 1.5223055826714547, 8.892617718062953, 17.999045982671525, 3.1118720565201747, 14.426716458595712, 30.835367028590046]
#xVal = [0.9035764868063162, 0.8245068620996813, 0.9893369695915014, 0.9687504122960724, 0.9715861011630148, 1.1541996100383012, 1.1208790448763097, 1.1753679218588817, 0.9985607802010937, 1.0171195977658123, 1.1253609114851, 1.1284467273860586, 1.096967080001515, 1.125197883219171, 1.0556359818019316, 1.0892435659069293, 0.9715886046950624, 0.9451122239844754, 0.9356387560111403, 0.6906133957499536, 1.0302888701760315, 1.0391207454420248, 1.010187615597733, 1.0031092126825893, 1.1639584771875384, 0.9432405216896838, 0.8098102068353351, 0.8318423184744109, 0.7778956604099209, 0.8493851036781035, 0.9703093362790548, 1.11762878585492, 1.0278573962529418, 1.0359721705749978, 1.0294029160806444, 1.0132092082013575, 0.9719133371253091, 1.0215014597414642, 1.0333923925106419, 1.1445422710417, 0.8681746980126387, 0.8268406961776065, 0.9988707975997508, 0.9844814671961067, 1.028584367829997, 1.0104056475216365, 0.9936010668829304, 0.9849421881530036, 1.1845505587736738, 1.1845505587736738, 0.9694267103695072, 0.9840977281799971, 1.127141924009304, 0.7675858992562403, 0.796838716601732, 0.708154795574862, 1.172470355332289, 0.9669080925207767, 0.9406387429313823, 1.0039801068889211, 0.9930624529949234, 0.9797173495222857, 0.960593578951494, 1.1845505587736738, 0.8694560897261261, 1.1483676838475105, 1.1883360923596429, 0.9102995885500312, 1.1845505587736738, 0.9665640051398836, 0.5786959410627814, 3.791220465237668, 7.584610426817192, 1.5223055826714547, 8.892617718062953, 17.999045982671525, 3.1118720565201747, 14.426716458595712, 30.835367028590046]
xVal = [0.9035764868063162, 0.8245068620996813, 0.9893369695915014, 0.9687504122960724, 0.9715861011630148, 1.1541996100383012, 1.1208790448763097, 1.1753679218588817, 0.9985607802010937, 1.0171195977658123, 1.1253609114851, 1.1284467273860586, 1.096967080001515, 1.125197883219171, 1.0556359818019316, 1.0892435659069293, 0.9715886046950624, 0.9451122239844754, 0.9356387560111403, 0.6906133957499536, 1.0302888701760315, 1.0391207454420248, 1.010187615597733, 1.0031092126825893, 1.1639584771875384, 0.9432405216896838, 0.8098102068353351, 0.8318423184744109, 0.7778956604099209, 0.8493851036781035, 0.9703093362790548, 1.11762878585492, 1.0278573962529418, 1.0359721705749978, 1.0294029160806444, 1.0132092082013575, 0.9719133371253091, 1.0215014597414642, 1.0333923925106419, 1.1445422710417, 0.8681746980126387, 0.8268406961776065, 0.9988707975997508, 0.9844814671961067, 1.028584367829997, 1.0104056475216365, 0.9936010668829304, 0.9849421881530036, 1.1845505587736738, 1.1845505587736738, 0.9694267103695072, 0.9840977281799971, 1.127141924009304, 0.7675858992562403, 0.796838716601732, 0.708154795574862, 1.172470355332289, 0.9669080925207767, 0.9406387429313823, 1.0039801068889211, 0.9930624529949234, 0.9797173495222857, 0.960593578951494, 1.1845505587736738, 0.8694560897261261, 1.1483676838475105, 1.1883360923596429, 0.9102995885500312, 1.1845505587736738, 0.9665640051398836, 0.5, 4.0, 8.0, 2.0, 10.0, 19.0, 3.5, 15.0, 31.0]
v_cs = xVal[1:70]
v_τ33 = (xVal[71], xVal[72], xVal[73])
v_τ34 = (xVal[74], xVal[75], xVal[76])
v_τ35 = (xVal[77], xVal[78], xVal[79])
v_τ = Dict(33 => v_τ33, 34 => v_τ34, 35 => v_τ35)
ItemType = Tuple{
    Float64,
    Dict{Int32,Tuple{Float64,Float64}},
    Dict{Int32,Tuple{Float64,Float64}},
    Float64,
    Float64,
    Tuple{Float64,Float64,Float64},
    Tuple{Float64,Float64,Float64},
}

function CosSqrvalue(
    t::Float64,
    v_c::Real,
    v_τ::Tuple{Real,Real,Real},
)
    v_τ1 = v_τ[1]
    v_τ2 = v_τ[2]
    v_τ3 = v_τ[3]
    if t < v_c * v_τ1
        2.0 - t / (v_c * v_τ1)
    elseif t < v_c * v_τ2
        3.0 - (t / v_c - v_τ1) / (v_τ2 - v_τ1)
    elseif t < v_c * v_τ3
        4.0 - (t / v_c - v_τ2) / (v_τ3 - v_τ2)
    else
        4.0
    end
end
function colValue(
    item::ItemType,
    i_c::Int,
    code::Int,
    isCurrent::Bool,
    v_cs::Array{Float64,1},
    v_τ::Dict{Int64,Tuple{Float64,Float64,Float64}},
)
    t = item[if isCurrent
        3
    else
        2
    end][code][1]
    v = item[if isCurrent
        3
    else
        2
    end][code][2]
    v_c = v_cs[i_c]
    CosSqrvalue(t, v_c, v_τ[code])
    #CosSqr.value(t, v_c, v_τ[code])
end
function getRow(
    item::ItemType,
    i_c::Int,
    v_cs::Array{Float64,1},
    v_τ::Dict{Int64,Tuple{Float64,Float64,Float64}},
    prevBgLevel::Float64,
)
    (
     item[1],
     prevBgLevel,
     colValue(item, i_c, 33, true, v_cs, v_τ),
     colValue(item, i_c, 34, true, v_cs, v_τ),
     colValue(item, i_c, 35, true, v_cs, v_τ),
     colValue(item, i_c, 33, false, v_cs, v_τ),
     colValue(item, i_c, 34, false, v_cs, v_τ),
     colValue(item, i_c, 35, false, v_cs, v_τ),
     item[4],
     item[5],
     item[6][1],
     item[6][2],
     item[6][3],
     item[7][1],
     item[7][2],
     item[7][3],
    )
end
function getTransactions(
    data::Array{Any,1},
    v_cs::Array{Float64,1},
    v_τ::Dict{Int64,Tuple{Float64,Float64,Float64}},
)
    result = []
    NumResult = 0
    #max_33_34_35 = Dict(33 => 0.0, 34 => 0.0, 35 => 0.0)
    #max_33_34_35_min = [0.0, 0.0, 0.0, 1000.0,1000.0,1000.0]
    for (i_c, record) in enumerate(data)
        prevBgLevel = 2.0
        for item in record

            #if item[2][33][1] > 24.0 || item[2][34][1] > 48.0 || item[2][35][1] > 120.0 || item[3][33][1] > 24.0 || item[3][34][1] > 48.0 || item[3][35][1] > 120.0
            #if item[2][33][1] > 12.0 || item[2][34][1] > 24.0 || item[2][35][1] > 48.0 || item[3][33][1] > 12.0 || item[3][34][1] > 24.0 || item[3][35][1] > 48.0
            if item[3][33][1] - item[2][33][1] == 0 || item[3][34][1] - item[2][34][1] == 0 || item[3][35][1] - item[2][35][1] == 0 ||
                item[3][33][1] - item[2][33][1] > 6.0 || item[3][34][1] - item[2][34][1] > 12.0 || item[3][35][1] - item[2][35][1] > 24.0
                continue
            end

            # if item[2][33][2] > max_33_34_35_min[1] || item[3][33][2] > max_33_34_35_min[1]
            #     max_33_34_35_min[1] = max(item[2][33][2], item[3][33][2])
            # end
            # if item[2][34][2] > max_33_34_35_min[2] || item[3][34][2] > max_33_34_35_min[2]
            #     max_33_34_35_min[2] = max(item[2][34][2], item[3][34][2])
            # end
            # if item[2][35][2] > max_33_34_35_min[3] || item[3][35][2] > max_33_34_35_min[3]
            #     max_33_34_35_min[3] = max(item[2][35][2], item[3][35][2])
            # end
            # if item[2][33][2] < max_33_34_35_min[4] || item[3][33][2] < max_33_34_35_min[4]
            #     max_33_34_35_min[4] = min(item[2][33][2], item[3][33][2])
            # end
            # if item[2][34][2] < max_33_34_35_min[5] || item[3][34][2] < max_33_34_35_min[5]
            #     max_33_34_35_min[5] = min(item[2][34][2], item[3][34][2])
            # end
            # if item[2][35][2] < max_33_34_35_min[6] || item[3][35][2] < max_33_34_35_min[6]
            #     max_33_34_35_min[6] = min(item[2][35][2], item[3][35][2])
            # end

                push!(result, getRow(item, i_c, v_cs, v_τ, prevBgLevel))
                NumResult = NumResult + 1
                prevBgLevel = item[1]


        end
    end
    #println("max_33_34_35_min = $max_33_34_35_min")
    println("NumResult = $(NumResult)")
    result = (("bgLevel", "prevBgLevel", "curr33", "curr34", "curr35", "prev33", "prev34", "prev35","DcurrBgLevel","DprevBgLevel","Dcurr33", "Dcurr34", "Dcurr35", "Dprev33", "Dprev34", "Dprev35"),
        result)
end
# counting to find interval points for the equal amounts.
function statisticsIntervals(result)
    # counting for minmum and maxmum
    numRows = length(result[2])
    # for colId = 9:16
    #     column = [result[2][rowId][colId] for rowId = 1:numRows]
    #     println(colId, ",", min(column...), ",", max(column...))
    # end
    for colId = 9:16
        colVector = [result[2][rowId][colId] for rowId = 1:numRows]
        colVectorWithoutNone = []
        for colVectorID = 1:length(colVector)
            if colVector[colVectorID] == 0.0
                continue
            end
            push!(colVectorWithoutNone, colVector[colVectorID])
        end
        sort!(colVectorWithoutNone)
        sumRowsWithoutNone = length(colVectorWithoutNone)
        colSpliters = colVectorWithoutNone[Int32(floor(sumRowsWithoutNone/5))*(1:4)]
        println("colSpliters of $(colId) = $(colSpliters);  length(colVectorWithoutNone) = $sumRowsWithoutNone")
    end
    # sort and find the medium data for 33, 34 and 35
    # fetched = [tr[3][35][2] for record in dataTransactions for tr in record]
    # sortedfetched = sort(fetched)
    # k = 0
    # for i in 1:length(sortedfetched)
    #     if sortedfetched[i]>0
    #         global k = i
    #         println("k = $k")
    #         break
    #     end
    # end
    # sortedfetched[Int(round((length(sortedfetched) + k) / 2.0))]
end

result = getTransactions(dataTransactions, v_cs, v_τ)
#tatisticsIntervals(result)
#@save "Transactions_timeParameters.jld2" result
#@save "Transactions_timeParameters_M10I5.jld2" result
@save "Transactions_timeParameters_FTARM_M.jld2" result
#@save "Transactions_timeParameters_FTARM.jld2" result
