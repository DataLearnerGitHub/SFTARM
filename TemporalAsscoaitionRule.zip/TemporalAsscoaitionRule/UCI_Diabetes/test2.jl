#include("generateTransactions_timeParameters_params.jl")
include("generateRulesDerivative_comparisons.jl")
@load "Results/Transactions_timeParameters.jld2" result
#println("huihui3")
path = "D:/zh/TemporalAsscoaitionRule20200901/Results/"
comparisonFilteredOutputRules = open(
    path * "comparisonFilteredOutputRules_ThreeMethods.txt",
    "w",
)
minSupp = 0.15
minConf = 0.15
freqSetList = Apriori(result, minSupp)
NumberOfRules = generate_TARules(
    comparisonFilteredOutputRules,
    freqSetList,
    minSupp,
    minConf,
)
#println("huihui5")
AvgConfidence = filterRules(comparisonFilteredOutputRules, minSupp, minConf)
@load path*"FilteredRules" FilteredRules

NumberOfFilteredRules = 0
AvgSupport = 0.0
AvgConfidence = 0.0
AvgLift = 0.0
for iFilteredRules = 1:length(FilteredRules)
    global NumberOfFilteredRules,AvgSupport,AvgConfidence,AvgLift
    consequent = FilteredRules[iFilteredRules][6]
    numConsequent = length(consequent)
    antecedent = FilteredRules[iFilteredRules][5]
    rule_of_key = union(antecedent, consequent)
    support_of_rule = freqSetList[length(rule_of_key)][rule_of_key]
    support_of_antecedent = freqSetList[length(antecedent)][antecedent]
    support_of_consequent = freqSetList[numConsequent][Set{Tuple{
        String,
        Int64,
    }}(consequent)]
    Confidence_current = support_of_rule / support_of_antecedent
    Lift_current = support_of_rule / support_of_consequent

    NumberOfFilteredRules = NumberOfFilteredRules + 1
    AvgSupport = AvgSupport + support_of_rule
    AvgConfidence = AvgConfidence + Confidence_current
    AvgLift = AvgLift + Lift_current
end

close(comparisonFilteredOutputRules)
