using JLD2
include("cossqr.jl")
#@load "data_preprocessing.jld2" dataTransactions xVal
#@load "data_preprocessing_FTARM.jld2" dataTransactions xVal
#@load "data_preprocessing_FTARM_M.jld2" dataTransactions xVal
SavePath = "Results/FTARMRandom/"
ItemType = Tuple{
    Float64,
    Dict{Int32,Tuple{Float64,Float64}},
    Dict{Int32,Tuple{Float64,Float64}},
    Float64,
    Float64,
    Tuple{Float64,Float64,Float64},
    Tuple{Float64,Float64,Float64},
}

function CosSqrvalue(
    t::Float64,
    v_c::Real,
    v_τ::Tuple{Real,Real,Real},
)
    v_τ1 = v_τ[1]
    v_τ2 = v_τ[2]
    v_τ3 = v_τ[3]
    if t < v_c * v_τ1
        2.0 - t / (v_c * v_τ1)
    elseif t < v_c * v_τ2
        3.0 - (t / v_c - v_τ1) / (v_τ2 - v_τ1)
    elseif t < v_c * v_τ3
        4.0 - (t / v_c - v_τ2) / (v_τ3 - v_τ2)
    else
        4.0
    end
end
function colValue(
    item::ItemType,
    i_c::Int,
    code::Int,
    isCurrent::Bool,
    v_cs::Array{Float64,1},
    v_τ::Dict{Int64,Tuple{Float64,Float64,Float64}},
)
    t = item[if isCurrent
        3
    else
        2
    end][code][1]
    v_c = v_cs[i_c]
    #CosSqrvalue(t, v_c, v_τ[code])
    CosSqr.value(t, v_c, v_τ[code])
end
function getRow(
    item::ItemType,
    i_c::Int,
    v_cs::Array{Float64,1},
    v_τ::Dict{Int64,Tuple{Float64,Float64,Float64}},
    prevBgLevel::Float64,
)
    (
     item[1],
     prevBgLevel,
     colValue(item, i_c, 33, true, v_cs, v_τ),
     colValue(item, i_c, 34, true, v_cs, v_τ),
     colValue(item, i_c, 35, true, v_cs, v_τ),
     colValue(item, i_c, 33, false, v_cs, v_τ),
     colValue(item, i_c, 34, false, v_cs, v_τ),
     colValue(item, i_c, 35, false, v_cs, v_τ),
     item[4],
     item[5],
     item[6][1],
     item[6][2],
     item[6][3],
     item[7][1],
     item[7][2],
     item[7][3],
    )
end

function getTransactions(
    data::Array{Any,1},
    v_cs::NTuple{70,Float64},
    v_τ::Dict{Int64,Tuple{Float64,Float64,Float64}},
)
    getTransactions(data, [v_cs...], v_τ)
end

function getTransactions(
    data::Array{Any,1},
    v_cs::Array{Float64,1},
    v_τ::Dict{Int64,Tuple{Float64,Float64,Float64}},
)
    result = []
    NumResult = 0
    for (i_c, record) in enumerate(data)
        prevBgLevel = 2.0
        for item in record

            #if item[2][33][1] > 24.0 || item[2][34][1] > 48.0 || item[2][35][1] > 120.0 || item[3][33][1] > 24.0 || item[3][34][1] > 48.0 || item[3][35][1] > 120.0
            #if item[2][33][1] > 12.0 || item[2][34][1] > 24.0 || item[2][35][1] > 48.0 || item[3][33][1] > 12.0 || item[3][34][1] > 24.0 || item[3][35][1] > 48.0
            if item[3][33][1] - item[2][33][1] == 0 || item[3][34][1] - item[2][34][1] == 0 || item[3][35][1] - item[2][35][1] == 0 ||
                item[3][33][1] - item[2][33][1] > 6.0 || item[3][34][1] - item[2][34][1] > 12.0 || item[3][35][1] - item[2][35][1] > 24.0
                continue
            end

                push!(result, getRow(item, i_c, v_cs, v_τ, prevBgLevel))
                NumResult = NumResult + 1
                prevBgLevel = item[1]


        end
    end
    #println("NumResult = $(NumResult)")
    result = (("bgLevel", "prevBgLevel", "curr33", "curr34", "curr35", "prev33", "prev34", "prev35","DcurrBgLevel","DprevBgLevel","Dcurr33", "Dcurr34", "Dcurr35", "Dprev33", "Dprev34", "Dprev35"),
        result)
end
# counting to find interval points for the equal amounts.
function statisticsIntervals(result)
    # counting for minmum and maxmum
    numRows = length(result[2])
    # for colId = 9:16
    #     column = [result[2][rowId][colId] for rowId = 1:numRows]
    #     println(colId, ",", min(column...), ",", max(column...))
    # end
    for colId = 9:16
        colVector = [result[2][rowId][colId] for rowId = 1:numRows]
        colVectorWithoutNone = []
        for colVectorID = 1:length(colVector)
            if colVector[colVectorID] == 0.0
                continue
            end
            push!(colVectorWithoutNone, colVector[colVectorID])
        end
        sort!(colVectorWithoutNone)
        sumRowsWithoutNone = length(colVectorWithoutNone)
        colSpliters = colVectorWithoutNone[Int32(floor(sumRowsWithoutNone/5))*(1:4)]
        println("colSpliters of $(colId) = $(colSpliters);  length(colVectorWithoutNone) = $sumRowsWithoutNone")
    end
end

# function adjustParams_generateTransactions(maxIter::Int, xVal::Array{Float64,1})
#     @load "Results/data_preprocessing_$(maxIter).jld2" dataTransactions xVal
#     v_cs = xVal[1:70]
#     v_τ33 = (xVal[71], xVal[72], xVal[73])
#     v_τ34 = (xVal[74], xVal[75], xVal[76])
#     v_τ35 = (xVal[77], xVal[78], xVal[79])
#     v_τ = Dict(33 => v_τ33, 34 => v_τ34, 35 => v_τ35)
#
#
#     result = getTransactions(dataTransactions, v_cs, v_τ)
#     @save "Results/Transactions_timeParameters_$(maxIter).jld2" result
#     #@save "Results/Transactions_timeParameters.jld2" result
# end
function adjustParams_generateTransactionsRandom(dataTransactions::Array{Any,1}, xVal::Union{Tuple, Array{Float64, 1}})::Union{Array{Symbol,1},Tuple}
    #@load "Results/data_preprocessing.jld2" dataTransactions xVal
    #println("adjustParams_generateTransactions(xVal) = $xVal")
    v_cs = xVal[1:70]
    v_τ33 = (xVal[71], xVal[72], xVal[73])
    v_τ34 = (xVal[74], xVal[75], xVal[76])
    v_τ35 = (xVal[77], xVal[78], xVal[79])
    v_τ = Dict(33 => v_τ33, 34 => v_τ34, 35 => v_τ35)
    result = getTransactions(dataTransactions, v_cs, v_τ)
    #@save PathAndNameToSave result
    #@save "Results/Transactions_timeParameters.jld2" result
    return result
end
#exit()
#adjustParams_generateTransactions(2)
#statisticsIntervals(result)
#@save "Transactions_timeParameters.jld2" result
#@save "Transactions_timeParameters_FTARM_M.jld2" result
#@save "Transactions_timeParameters_FTARM.jld2" result
