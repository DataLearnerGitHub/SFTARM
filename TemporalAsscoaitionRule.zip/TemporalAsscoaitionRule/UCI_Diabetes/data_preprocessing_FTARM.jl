include("ucid.jl")
include("cossqr.jl")
include("igfactor.jl")
include("process.jl")

using Dates
using JuMP
using Ipopt
using JLD2

# raw data from uci diabetes

path= "/Users/hui/work/Programs/TemporalAsscoaitionRule20200901"
#path= "/Users/hui/work/Programs/TemporalAsscoaitionRule20200901/Results/test202101/"
rawData = UCID.loadUCIDiabetes(path)

# variables and symbols for duration scaling
knownCode = [33, 34, 35]
addCode = [65, 66, 67, 68, 69, 70, 71, 72]
allCode = [33, 34, 35, 65, 66, 67, 68, 69, 70, 71, 72]

nData = size(rawData, 1)
nX = nData + size(knownCode, 1) * 3
varOffset = Dict(33 => nData, 34 => nData + 3, 35 => nData + 6)
# model = Model(with_optimizer(
#     Ipopt.Optimizer,
#     max_iter = 0,
#     adaptive_mu_globalization = "never-monotone-mode",
# ))
model = Model(optimizer_with_attributes(
    Ipopt.Optimizer,
    "max_iter" => 0,
    "adaptive_mu_globalization" => "never-monotone-mode",
))
# τ33_init = [0.5, 2.5, 7.5]
# τ34_init = [2, 7, 19]
# τ35_init = [3.5, 4, 31]
# τ33_init = [0.5, 2, 5]
# τ34_init = [2, 5, 12]
# τ35_init = [3.5, 15, 27]
τ33_init = [0.5, 4.0, 8.0]
τ34_init = [2.0, 10.0, 19.0]
τ35_init = [3.5, 15.0, 31.0]
function x0(i)
    if i <= nData
        1.0
    elseif i <= nData + 3
        τ33_init[i-nData]
    elseif i <= nData + 6
        τ34_init[i-nData-3]
    else
        τ35_init[i-nData-6]
    end
end
@variable(model, x[i = 1:nX] >= 0.001, start = x0(i))
for i = 1:nData
    @constraint(model, x[i] <= 3.0)
end
for code in knownCode
    @constraint(model, x[varOffset[code]+1] + 0.001 <= x[varOffset[code]+2])
    @constraint(model, x[varOffset[code]+2] + 0.001 <= x[varOffset[code]+3])
    @constraint(model, x[varOffset[code]+3] <= 2.0 * x0(varOffset[code] + 3))
end
@constraint(model, sum(x[1:nData]) == nData)
# convert DateTime into propority of hours
function tToDiffT(t::DateTime, act::Dict{Int32,Tuple{DateTime,Float64}})
    result = Dict{Int32,Tuple{Float64,Float64}}()
    for code in keys(act)
        (refT, actValue) = act[code]
        @assert t >= refT
        diffT = (t - refT) / Millisecond(Hour(1))
        #result[code] = (diffT, actValue)
        weightedValue = actValue
        if weightedValue > 32
            weightedValue = 32
        end
        weightTime = 2 - weightedValue / 16
        result[code] = (weightTime * diffT, actValue)
    end
    result
end

# define a fuzzified blood glucose levels:
function bgLevel(x::Float64)
    if 40.0 <= x < 80.0
        2.0 - (80.0 - x) / 40.0
    elseif 80.0 <= x < 130.0
        2.0
    elseif 130.0 <= x < 300.0
        3.0 - (300.0 - x) / 170.0
    elseif x >= 300.0
        3.0
    else
        1.0
    end
end
# function derivativeBgFuzzy(x::Float64)
#     if x < -12.0
#         -2.0
#     elseif -12.0 <= x < -3.0
#         -2.0 - x / 24.0
#     elseif  -3.0 <= x < -1.0
#         -1.5 - x / 6.0
#     elseif -1.0 <= x < 1.0
#         x
#     elseif 2.5 > x >= 1.0
#         1.0 + x / 5.0
#     elseif 11 > x >= 2.5
#         1.5 + x / 22.0
#     else
#         2.0
#     end
# end
# function derivativeInFuzzy(x::Float64)
#     if x < -1.0
#         -2.0
#     elseif -1.0 <= x < -0.1
#         -2.0 - x / 2.0
#     elseif -0.1 <= x < 0.1
#         10x
#     elseif 0.4 > x >= 0.1
#         1.0 + x / 0.4
#     elseif 1.0 > x >= 0.4
#         1.0 + x / 2.0
#     else
#         2.0
#     end
# end
function derivativeBgFuzzy(x::Float64)
    if x < -12.0
        -2.0
    elseif -12.0 <= x < -3.0
        -1.5 + 0.5(x + 3.0) / 9.0
    elseif  -3.0 <= x < -1.0
        -1.0 + 0.5(x + 1.0) / 2.0
    elseif -1.0 <= x < 1.0
        x
    elseif 2.5 > x >= 1.0
        1.0 + 0.5(x - 1.0) / 1.5
    elseif 11 > x >= 2.5
        1.5 + 0.5(x - 2.5) / 8.5
    else
        2.0
    end
end
function derivativeInFuzzy(x::Float64)
    if x < -1.0
        -2.0
    elseif -1.0 <= x < -0.1
        #-2.0 - x / 2.0
        -1.0 + (x + 0.1) / 0.9
    elseif -0.1 <= x < 0.1
        10x
    elseif 0.4 > x >= 0.1
        #1.0 + x / 0.4
        1.0 + 0.5(x -0.1) / 0.3
    elseif 1.0 > x >= 0.4
        1.5 + 0.5(x - 0.4) / 0.6
    else
        2.0
    end
end
# function derivativeBgFuzzy(x::Float64)
#     if x < -12.0
#         -2.0
#     elseif -12.0 <= x < -1.0
#         -2.0 - x / 12.0
#     elseif -1.0 <= x < 1.0
#         x
#     elseif 11 > x >= 1.0
#         1.0 + x / 11.0
#     else
#         2.0
#     end
# end
# function derivativeInFuzzy(x::Float64)
#     if x < -2.0
#         -2.0
#     elseif -2.0 <= x < -1.0
#         x
#     elseif -1.0 <= x < 1.0
#         x
#     elseif 2.0 > x > 1.0
#         x
#     else
#         2.0
#     end
# end
function derivativeAct(
    curract::Dict{Int32,Tuple{DateTime,Float64}},
    prevact::Dict{Int32,Tuple{DateTime,Float64}},
)
    currDerivativeAct = []
    for code in keys(curract)
        (currRefT, currActValue) = curract[code]
        (prevRefT, prevActValue) = prevact[code]
        if currRefT == prevRefT
            push!(currDerivativeAct, 0.0)
        else
            push!(
                currDerivativeAct,
                # (currActValue - prevActValue) /
                #                   ((currRefT - prevRefT) /
                #                    Millisecond(Hour(1))),
                derivativeInFuzzy((currActValue - prevActValue) /
                                  ((currRefT - prevRefT) /
                                   Millisecond(Hour(1)))),
            )
        end
    end
    Tuple(currDerivativeAct)
end
function derivativeAct(
    curract::Tuple{DateTime,Float64},
    prevact::Tuple{DateTime,Float64},
)
    (currRefT, currActValue) = curract
    (prevRefT, prevActValue) = prevact
    if currRefT == prevRefT
        0.0
    else
        # (currActValue - prevActValue) /
        #                   ((currRefT - prevRefT) / Millisecond(Hour(1)))
        derivativeBgFuzzy((currActValue - prevActValue) /
                          ((currRefT - prevRefT) / Millisecond(Hour(1))))
    end
end
# convert data record to diffT
function recordToDiffT(record::Array{UCID.Activity,1})
    result = []
    transactions = []
    dateTime0 = DateTime("1-1-0 0:0", "m-d-y H:M")
    nilActStat = (dateTime0, 0.0)
    prevprevAct = Dict{Int32,Tuple{DateTime,Float64}}(
        33 => nilActStat,
        34 => nilActStat,
        35 => nilActStat,
    )
    prevAct = Dict{Int32,Tuple{DateTime,Float64}}(
        33 => nilActStat,
        34 => nilActStat,
        35 => nilActStat,
    )
    currAct = Dict{Int32,Tuple{DateTime,Float64}}(
        33 => nilActStat,
        34 => nilActStat,
        35 => nilActStat,
    )
    currBgAct = nilActStat
    prevBgAct = nilActStat
    prevprevBgAct = nilActStat
    for act in record
        if act.code in keys(currAct)
            prevprevAct[act.code] = prevAct[act.code]
            prevAct[act.code] = currAct[act.code]
            currAct[act.code] = (act.dateTime, act.value)
        elseif 48 <= act.code <= 64
            currBgAct = (act.dateTime, act.value)

            push!(
                result,
                (
                 bgLevel(act.value),
                 tToDiffT(act.dateTime, prevAct),
                 tToDiffT(act.dateTime, currAct),
                ),
            )

            push!(
                transactions,
                (
                 bgLevel(act.value),
                 tToDiffT(act.dateTime, prevAct),
                 tToDiffT(act.dateTime, currAct),
                 derivativeAct(currBgAct, prevBgAct),
                 derivativeAct(prevBgAct, prevprevBgAct),
                 derivativeAct(currAct, prevAct),
                 derivativeAct(prevAct, prevprevAct),
                 # (DC33, DC34, DC35) = derivativeAct(currAct, prevAct),
                 # (DP33, DP34, DP35) = derivativeAct(prevAct, prevprevAct),
                ),
            )

            prevprevBgAct = prevBgAct
            prevBgAct = currBgAct
        end
    end
    (result, transactions)
end

data = []
dataTransactions = []
for record in rawData
    (result, transactions) = recordToDiffT(record)
    push!(data, result)
    push!(dataTransactions, transactions)
end
function f(xVal...)
    inputs = []
    global knownCode, varOffset
    for (k, record) in enumerate(data)
        for (bg, prevAct, currAct) in record
            valueArray = Array{Float64,1}()
            for code in knownCode
                for diffT in [prevAct[code][1], currAct[code][1]]
                    value = CosSqr.value(
                        diffT,
                        xVal[k],
                        xVal[varOffset[code].+(1:3)],
                    )
                    push!(valueArray, value)
                end
            end
            push!(inputs, IGFactor.InputValue(bg, valueArray))
        end
    end
    IGFactor.value(inputs)
end
function ∇f!(g, xVal...)
    for (iX, varX) in enumerate(x)
        g[iX] = 0.0
    end
end
# function ∇f!(g, xVal...)
#     inputs = []
#     global knownCode, varOffset, x
#     for (k, record) in enumerate(data)
#         for (bg, prevAct, currAct) in record
#             dwrtArray = Array{IGFactor.EvalDict,1}()
#             for code in knownCode
#                 for diffT in [prevAct[code][1], currAct[code][1]]
#                     dwrt = CosSqr.dwrt(
#                         diffT,
#                         x[k],
#                         x[varOffset[code].+(1:3)],
#                         xVal[k],
#                         xVal[varOffset[code].+(1:3)],
#                     )
#                     push!(dwrtArray, dwrt)
#                 end
#             end
#             push!(inputs, IGFactor.InputDwrt(bg, dwrtArray))
#         end
#     end
#     dwrt = IGFactor.dwrt(inputs)
#     for (iX, varX) in enumerate(x)
#         g[iX] = get(dwrt, varX, 0.0)
#     end
# end
# counting to find interval points for the equal amounts.
function statisticsIntervals(dataTransactions)
    # counting for minmum and maxmum
    numRows = length(dataTransactions)
    # for colId = 9:16
    #     column = [result[2][rowId][colId] for rowId = 1:numRows]
    #     println(colId, ",", min(column...), ",", max(column...))
    # end
    for colId = 9:16
        colVector = [dataTransactions[rowId][colId] for rowId = 1:numRows]
        println(colVector[1:3])
        sort!(colVector)
        colSpliters = colVector[Int32(floor(numRows/5))*(1:4)]
        println("colSpliters of $(colId) = $(colSpliters)")
    end
end

#JuMP.register(model, :f, nX, f, ∇f!)
#@NLobjective(model, Max, f(x...))
# @load "x.jld2" x
#optimize!(model)
xVal = fill(0.0, length(x))
for i in 1:length(x)
    xVal[i] = x0(i)
end
# println("data ...")
# statisticsIntervals(data)
# println("dataTransactions ...")
# statisticsIntervals(dataTransactions)

# println(typeof(xVal))
# # xVal = [0.9014636924122406, 1.7162888154530627, 1.0176567703866575, 1.0074309899775797, 1.0225426007469465, 0.9873851914635534, 0.9928291697409601, 1.0316507965915755, 0.97738560715167, 1.0065390353943369, 0.9803275482260423, 0.9686414015946319, 0.9692764967780497, 1.0614937196710579, 1.1114459049154344, 1.0336364883471032, 0.9616153661763689, 1.0160812320271735, 1.0566873272912105, 0.4823485633164202, 0.9527633598621101, 1.030244073075658, 0.9928812835672751, 1.004950633050651, 0.9946188975152397, 0.8745483706351287, 0.8595062239081808, 1.3606782992273299, 1.2412562354781835, 0.7017420188408325, 1.0209410741462819, 0.8961155781451281, 0.8693964372570432, 0.8692095262108568, 0.9312345036637923, 0.8914867000485328, 0.964347429716427, 0.8765222369167509, 0.8743605428167595, 0.9698803619089347, 1.6052955478436794, 1.2769286786907206, 0.9827761033836834, 1.0002058337774695, 0.860529117179291, 0.9948000640908523, 0.9917222868380864, 0.9771380259400072, 1.039101100411017, 1.039101100411017, 1.0462569061494988, 1.0030786532574751, 0.9948149212970603, 0.7735802817618299, 0.6878999936937246, 0.6758763093882354, 1.0459493971407794, 0.9898079100380281, 0.9929532345252051, 0.9999994759779505, 0.9919355329398696, 0.9861582171929234, 0.9863893017398293, 1.039101100411017, 1.3378345110304974, 0.9757052793732518, 1.0379528452897548, 0.9873455327351867, 1.039101100411017, 1.1612511334278768, 2.0273142986382355, 4.5042289694591675, 8.655391017636864, 1.5371083456523387, 5.15263805818052, 15.59841318586719, 2.7568343519193528, 4.436700446603627, 29.304389094150885]

#xVal = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 2.0273142986382355, 4.5042289694591675, 8.655391017636864, 1.5371083456523387, 5.15263805818052, 15.59841318586719, 2.7568343519193528, 4.436700446603627, 29.304389094150885]
# xVal[71] = 2.0273142986382355
# xVal[74] = 1.5371083456523387
# #xVal[77] = 2.7568343519193528
# xVal[79] = 29.304389094150885
#statisticsIntervals(dataTransactions)
#@save "data_preprocessing_FTARM.jld2" dataTransactions xVal
#@save "data_preprocessing_FTARM_M.jld2.jld2" dataTransactions xVal
