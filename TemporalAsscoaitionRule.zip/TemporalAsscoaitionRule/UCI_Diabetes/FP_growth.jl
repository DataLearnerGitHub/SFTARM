using JLD2
FreqItemType = Tuple{String,Int}
FreqSetType = Set{FreqItemType}
FreqCountDict = Dict{FreqSetType,Float64}
@load "002.jld2" result
mutable struct FP_treeType
    IAttribute::Tuple{String, Int32}
    Count_support::Float32
    Parent::Union{FP_treeType, Nothing}
    Next_Node::Union{FP_treeType, Nothing}
    Children::Dict{Tuple{String, Int32}, FP_treeType}
end

#function FP_grow(result, minSupp)

    tableHead = result[1]
    numCols = length(tableHead)
    colNameToColIndex = Dict()
    for iCol = 1:numCols
        colNameToColIndex[tableHead[iCol]] = iCol
    end
    numTransactions = length(result[2])
    function filterFreqSet(counter, minSupp)
        newCounter = FreqCountDict()
        for (key, val) in counter
            if val >= minSupp
                newCounter[key] = val
            end
            for freqItem in key
                colName = freqItem[1]
                itemLevel = freqItem[2]
            end
        end
        newCounter
    end

    function find1FreqSet(result, minSupp)
        counter = FreqCountDict(
            Set([("bgLevel", 1)]) => 0.0,
            Set([("bgLevel", 2)]) => 0.0,
            Set([("bgLevel", 3)]) => 0.0,
        )
        for i = 2:numCols
            for j = 1:4
                counter[Set([(tableHead[i], j)])] = 0.0
            end
        end
        for transaction in result[2]
            for iCol = 1:numCols
                colName = tableHead[iCol]
                colVal = transaction[iCol]
                lowSet = Set([(colName, Int(floor(colVal)))])
                counter[lowSet] += floor(colVal) + 1 - colVal
                if ceil(colVal) == floor(colVal)
                    continue
                end
                highSet = Set([(colName, Int(floor(colVal)) + 1)])
                counter[highSet] += colVal - floor(colVal)
            end
        end
        for (key, val) in counter
            counter[key] = val / numTransactions
        end

        filterFreqSet(counter, minSupp)
    end

    function keyItemSet(key)
        retSet = Set()
        for item in key
            push!(retSet, item[1])
        end
        retSet
    end
    function hasChild(
        FP_treeType_Root::FP_treeType,
        FP_treeType_Current::FP_treeType,
        FP_treeType_CHead::FP_treeType,
        Level_Current::Int64,
    )
        FP_treeType_Parent = FP_treeType_Root
        for iLevel = 1:Level_Current
            for iIAttribute in keys(FP_treeType_Parent.Children)
                if iIAttribute == FP_treeType_CHead.IAttribute
                    FP_treeType_Parent = FP_treeType_Parent.Children[iIAttribute]
                end
            end
        end
        FP_treeType_Parent
    end
    function constructFPgrowthTree(result, minSupp)
        prevCounter = find1FreqSet(result, minSupp)
        FP_treeType_NULL = FP_treeType(
            ("NULL", 0),
            -2.0,
            nothing,
            nothing,
            Dict{Tuple{String,Int32},FP_treeType}(),
        )
        TypeTableTreeHead = Array{Tuple{Tuple{String,Int32},Float32,FP_treeType},1}
        tableTreeHead = TypeTableTreeHead()
        for (key, val) in prevCounter
            for kkey in key
                push!(tableTreeHead, (kkey, val, FP_treeType_NULL))
            end
        end
        tableTreeHeadDescending = sort(
            tableTreeHead,
            lt = (x, y) -> x[2] < y[2],
            rev = true,
        )
        println("constructing FPgrowth tree")
        FP_treeType_Root = FP_treeType(
            ("root", -1),
            -1.0,
            nothing,
            nothing,
            Dict{Tuple{String,Int32},FP_treeType}(),
        )

        counter = FreqCountDict(
            Set([("bgLevel", 1)]) => 0.0,
            Set([("bgLevel", 2)]) => 0.0,
            Set([("bgLevel", 3)]) => 0.0,
        )
        for i = 2:numCols
            for j = 1:4
                counter[Set([(tableHead[i], j)])] = 0.0
            end
        end
        for transaction in result[2]
            Node_parent = FP_treeType_Root
            FP_treeType_CHead = FP_treeType_Root
            #FP_treeType(tableTreeHeadDescending[1][1], 0.0, )
            for iTreeHead = 1:length(tableTreeHeadDescending)

                for iCol = 1:numCols
                    colName = tableHead[iCol]
                    colVal = transaction[iCol]
                    lowSet = Set([(colName, Int(floor(colVal)))])
                    if lowSet == Set(Tuple{String,Int64}[tableTreeHeadDescending[iTreeHead][1]])
                        support = floor(colVal) + 1 - colVal
                        FP_treeType_current = FP_treeType(tableTreeHeadDescending[iTreeHead][1], support, Node_parent, nothing, Dict{Tuple{String,Int32},FP_treeType}())
                        FP_treeType_Parent = hasChild(FP_treeType_Root, FP_treeType_current, FP_treeType_CHead, iTreeHead)
                        if FP_treeType_Parent.Count_support > -1.0
                            FP_treeType_current = FP_treeType_Parent
                            FP_treeType_current.support += support
                        end
                        if iTreeHead == 1
                            FP_treeType_CHead = FP_treeType_current
                        end
                        Node_parent.Children[tableTreeHeadDescending[iTreeHead][1]] = FP_treeType_current
                        Node_parent = FP_treeType_current
                        break
                    end
                    if ceil(colVal) == floor(colVal)
                        continue
                    end
                    highSet = Set([(colName, Int(floor(colVal)) + 1)])
                    if highSet == Set(Tuple{String,Int64}[tableTreeHeadDescending[iTreeHead][1]])
                        support = colVal - floor(colVal)
                        FP_treeType_current = FP_treeType(tableTreeHeadDescending[iTreeHead][1], support, Node_parent, Dict{Tuple{String,Int32},FP_treeType}())
                        FP_treeType_Parent = hasChild(FP_treeType_Root, FP_treeType_current, FP_treeType_CHead, iTreeHead)
                        if FP_treeType_Parent.Count_support > -1.0
                            FP_treeType_current = FP_treeType_Parent
                            FP_treeType_current.support += support
                        end

                        if iTreeHead == 1
                            FP_treeType_CHead = FP_treeType_current
                        end
                        Node_parent.Children[tableTreeHeadDescending[iTreeHead][1]] = FP_treeType_current
                        Node_parent = FP_treeType_current
                        break
                    end
                end
            end
        end
        for (key, val) in counter
            counter[key] = val / numTransactions
        end
        filterFreqSet(counter, minSupp)
        #tableTreeHeadDescending
    end
    function findFreqSetList()

    end







#end

freqSetList = constructFPgrowthTree(result, minSupp)(result, 0.3)
