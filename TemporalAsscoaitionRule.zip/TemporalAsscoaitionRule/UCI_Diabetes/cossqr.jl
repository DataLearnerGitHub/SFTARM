module CosSqr

using JuMP
export value, dwrt

function value(
    t::Float64,
    v_c::Real,
    v_τ::Tuple{Real,Real,Real},
)
    v_τ1 = v_τ[1]
    v_τ2 = v_τ[2]
    v_τ3 = v_τ[3]
    if t < v_c * v_τ1
        θ = π * t / (v_c * v_τ1)
        f = 1.5 - 0.5 * cos(θ)
        if f ≈ round(f)
            round(f)
        else
            f
        end
    elseif t < v_c * v_τ2
        θ = π * (t / v_c - v_τ1) / (v_τ2 - v_τ1)
        f = 2.5 - 0.5 * cos(θ)
        if f ≈ round(f)
            round(f)
        else
            f
        end
    elseif t < v_c * v_τ3
        θ = π * (t / v_c - v_τ2) / (v_τ3 - v_τ2)
        f = 3.5 - 0.5 * cos(θ)
        if f ≈ round(f)
            round(f)
        else
            f
        end
    else
        4.0
    end
end

function dwrt(
    t::Float64,
    c::VariableRef,
    τ::Array{VariableRef,1},
    v_c::Real,
    v_τ::Tuple{Real,Real,Real},
)
    v_τ1 = v_τ[1]
    v_τ2 = v_τ[2]
    v_τ3 = v_τ[3]
    if t < v_c * v_τ1
        θ = π * t / (v_c * v_τ1)
        f = 1.5 - 0.5 * cos(θ)
        if f ≈ round(f)
            Dict(nothing => round(f))
        else
            ∂θ_c = -θ / v_c
            ∂θ_τ1 = -θ / v_τ1
            ∂f_θ = 0.5 * sin(θ)

            Dict(nothing => f, c => ∂f_θ * ∂θ_c, τ[1] => ∂f_θ * ∂θ_τ1)
        end
    elseif t < v_c * v_τ2
        θ = π * (t / v_c - v_τ1) / (v_τ2 - v_τ1)
        f = 2.5 - 0.5 * cos(θ)
        if f ≈ round(f)
            Dict(nothing => round(f))
        else
            θ_0 = -π * v_τ1 / (v_τ2 - v_τ1)
            ∂θ_c = (θ_0 - θ) / v_c
            ∂θ_τ1 = (θ - π) / (v_τ2 - v_τ1)
            ∂θ_τ2 = -θ / (v_τ2 - v_τ1)
            ∂f_θ = 0.5 * sin(θ)

            Dict(
                nothing => f,
                c => ∂f_θ * ∂θ_c,
                τ[1] => ∂f_θ * ∂θ_τ1,
                τ[2] => ∂f_θ * ∂θ_τ2,
            )
        end
    elseif t < v_c * v_τ3
        θ = π * (t / v_c - v_τ2) / (v_τ3 - v_τ2)
        f = 3.5 - 0.5 * cos(θ)
        if f ≈ round(f)
            Dict(nothing => round(f))
        else
            θ_0 = -π * v_τ2 / (v_τ3 - v_τ2)
            ∂θ_c = (θ_0 - θ) / v_c
            ∂θ_τ2 = (θ - π) / (v_τ3 - v_τ2)
            ∂θ_τ3 = -θ / (v_τ3 - v_τ2)
            ∂f_θ = 0.5 * sin(θ)

            Dict(
                nothing => f,
                c => ∂f_θ * ∂θ_c,
                τ[2] => ∂f_θ * ∂θ_τ2,
                τ[3] => ∂f_θ * ∂θ_τ3,
            )
        end
    else
        Dict(nothing => 4.0)
    end
end

end
