include("ucid.jl")

include("cossqr.jl")
include("igfactor.jl")
include("process.jl")
include("generateTransactions_timeParameters_params.jl")
include("generateRulesDerivative.jl")

#include("aprioriDerivative_params.jl")

using Dates
using JuMP
using Ipopt
using JLD2
using FiniteDifferences
using LinearAlgebra


# convert DateTime into propority of hours
function tToDiffT(t::DateTime, act::Dict{Int32,Tuple{DateTime,Float64}})
    result = Dict{Int32,Tuple{Float64,Float64}}()
    for code in keys(act)
        (refT, actValue) = act[code]
        @assert t >= refT
        diffT = (t - refT) / Millisecond(Hour(1))
        result[code] = (diffT, actValue)
    end
    result
end

# define a fuzzified blood glucose levels:
function bgLevel(x::Float64)
    if 40.0 <= x < 80.0
        2.0 - (80.0 - x) / 40.0
    elseif 80.0 <= x < 130.0
        2.0
    elseif 130.0 <= x < 300.0
        3.0 - (300.0 - x) / 170.0
    elseif x >= 300.0
        3.0
    else
        1.0
    end
end
# function derivativeBgFuzzy(x::Float64)
#     if x < -12.0
#         -2.0
#     elseif -12.0 <= x < -3.0
#         -2.0 - x / 24.0
#     elseif -3.0 <= x < -1.0
#         -1.5 - x / 6.0
#     elseif -1.0 <= x < 1.0
#         x
#     elseif 2.5 > x >= 1.0
#         1.0 + x / 5.0
#     elseif 11 > x >= 2.5
#         1.5 + x / 22.0
#     else
#         2.0
#     end
# end
# function derivativeInFuzzy(x::Float64)
#     if x < -1.0
#         -2.0
#     elseif -1.0 <= x < -0.1
#         -2.0 - x / 2.0
#     elseif -0.1 <= x < 0.1
#         10x
#     elseif 0.4 > x >= 0.1
#         1.0 + x / 0.4
#     elseif 1.0 > x >= 0.4
#         1.0 + x / 2.0
#     else
#         2.0
#     end
# end
function derivativeBgFuzzy(x::Float64)
    if x < -12.0
        -2.0
    elseif -12.0 <= x < -3.0
        -1.5 + 0.5(x + 3.0) / 9.0
    elseif  -3.0 <= x < -1.0
        -1.0 + 0.5(x + 1.0) / 2.0
    elseif -1.0 <= x < 1.0
        x
    elseif 2.5 > x >= 1.0
        1.0 + 0.5(x - 1.0) / 1.5
    elseif 11 > x >= 2.5
        1.5 + 0.5(x - 2.5) / 8.5
    else
        2.0
    end
end
function derivativeInFuzzy(x::Float64)
    if x < -1.0
        -2.0
    elseif -1.0 <= x < -0.1
        #-2.0 - x / 2.0
        -1.0 + (x + 0.1) / 0.9
    elseif -0.1 <= x < 0.1
        10x
    elseif 0.4 > x >= 0.1
        #1.0 + x / 0.4
        1.0 + 0.5(x -0.1) / 0.3
    elseif 1.0 > x >= 0.4
        1.5 + 0.5(x - 0.4) / 0.6
    else
        2.0
    end
end
function derivativeAct(
    curract::Dict{Int32,Tuple{DateTime,Float64}},
    prevact::Dict{Int32,Tuple{DateTime,Float64}},
)
    currDerivativeAct = []
    for code in keys(curract)
        (currRefT, currActValue) = curract[code]
        (prevRefT, prevActValue) = prevact[code]
        if currRefT == prevRefT
            push!(currDerivativeAct, 0.0)
        else
            push!(
                currDerivativeAct,
                # (currActValue - prevActValue) /
                #                   ((currRefT - prevRefT) /
                #                    Millisecond(Hour(1))),
                derivativeInFuzzy((currActValue - prevActValue) /
                                  ((currRefT - prevRefT) /
                                   Millisecond(Hour(1)))),
            )
        end
    end
    Tuple(currDerivativeAct)
end
function derivativeAct(
    curract::Tuple{DateTime,Float64},
    prevact::Tuple{DateTime,Float64},
)
    (currRefT, currActValue) = curract
    (prevRefT, prevActValue) = prevact
    if currRefT == prevRefT
        0.0
    else
        # (currActValue - prevActValue) /
        #                   ((currRefT - prevRefT) / Millisecond(Hour(1)))
        derivativeBgFuzzy((currActValue - prevActValue) /
                          ((currRefT - prevRefT) / Millisecond(Hour(1))))
    end
end
# convert data record to diffT
function recordToDiffT(record::Array{UCID.Activity,1})
    result = []
    transactions = []
    dateTime0 = DateTime("1-1-0 0:0", "m-d-y H:M")
    nilActStat = (dateTime0, 0.0)
    prevprevAct = Dict{Int32,Tuple{DateTime,Float64}}(
        33 => nilActStat,
        34 => nilActStat,
        35 => nilActStat,
    )
    prevAct = Dict{Int32,Tuple{DateTime,Float64}}(
        33 => nilActStat,
        34 => nilActStat,
        35 => nilActStat,
    )
    currAct = Dict{Int32,Tuple{DateTime,Float64}}(
        33 => nilActStat,
        34 => nilActStat,
        35 => nilActStat,
    )
    currBgAct = nilActStat
    prevBgAct = nilActStat
    prevprevBgAct = nilActStat
    for act in record
        if act.code in keys(currAct)
            prevprevAct[act.code] = prevAct[act.code]
            prevAct[act.code] = currAct[act.code]
            currAct[act.code] = (act.dateTime, act.value)
        elseif 48 <= act.code <= 64
            currBgAct = (act.dateTime, act.value)

            push!(
                result,
                (
                 bgLevel(act.value),
                 tToDiffT(act.dateTime, prevAct),
                 tToDiffT(act.dateTime, currAct),
                ),
            )

            push!(
                transactions,
                (
                 bgLevel(act.value),
                 tToDiffT(act.dateTime, prevAct),
                 tToDiffT(act.dateTime, currAct),
                 derivativeAct(currBgAct, prevBgAct),
                 derivativeAct(prevBgAct, prevprevBgAct),
                 derivativeAct(currAct, prevAct),
                 derivativeAct(prevAct, prevprevAct),
                 # (DC33, DC34, DC35) = derivativeAct(currAct, prevAct),
                 # (DP33, DP34, DP35) = derivativeAct(prevAct, prevprevAct),
                ),
            )

            prevprevBgAct = prevBgAct
            prevBgAct = currBgAct
        end
    end
    (result, transactions)
end


# counting to find interval points for the equal amounts.
function statisticsIntervals(dataTransactions)
    # counting for minmum and maxmum
    numRows = length(dataTransactions)
    # for colId = 9:16
    #     column = [result[2][rowId][colId] for rowId = 1:numRows]
    #     println(colId, ",", min(column...), ",", max(column...))
    # end
    for colId = 9:16
        colVector = [dataTransactions[rowId][colId] for rowId = 1:numRows]
        println(colVector[1:3])
        sort!(colVector)
        colSpliters = colVector[Int32(floor(numRows / 5))*(1:4)]
        println("colSpliters of $(colId) = $(colSpliters)")
    end
end

function adjustParams_dataPreprocessing(maxIter)
    # raw data from uci diabetes
    path = "/Users/hui/work/Programs/TemporalAsscoaitionRule20200901"
    rawData = UCID.loadUCIDiabetes(path)
    # variables and symbols for duration scaling
    knownCode = [33, 34, 35]
    addCode = [65, 66, 67, 68, 69, 70, 71, 72]
    allCode = [33, 34, 35, 65, 66, 67, 68, 69, 70, 71, 72]
    nData = size(rawData, 1)
    nX = nData + size(knownCode, 1) * 3
    varOffset = Dict(33 => nData, 34 => nData + 3, 35 => nData + 6)
    model = Model(with_optimizer(
        Ipopt.Optimizer,
        max_iter = maxIter,
        adaptive_mu_globalization = "never-monotone-mode",
    ))
    τ33_init = [0.5, 2.5, 7.5]
    τ34_init = [2, 7, 19]
    τ35_init = [3.5, 4, 31]
    function x0(i)
        if i <= nData
            1.0
        elseif i <= nData + 3
            τ33_init[i-nData]
        elseif i <= nData + 6
            τ34_init[i-nData-3]
        else
            τ35_init[i-nData-6]
        end
    end
    @variable(model, x[i = 1:nX] >= 0.001, start = x0(i))
    for i = 1:nData
        @constraint(model, x[i] <= 3.0)
    end
    for code in knownCode
        @constraint(model, x[varOffset[code]+1] + 0.001 <= x[varOffset[code]+2])
        @constraint(model, x[varOffset[code]+2] + 0.001 <= x[varOffset[code]+3])
        @constraint(
            model,
            x[varOffset[code]+3] <= 2.0 * x0(varOffset[code] + 3),
        )
    end
    @constraint(model, sum(x[1:nData]) == nData)
    # function f(xVal...)
    #     inputs = []
    #     #global knownCode, varOffset
    #     for (k, record) in enumerate(data)
    #         for (bg, prevAct, currAct) in record
    #             valueArray = Array{Float64,1}()
    #             for code in knownCode
    #                 for diffT in [prevAct[code][1], currAct[code][1]]
    #                     value = CosSqr.value(
    #                         diffT,
    #                         xVal[k],
    #                         xVal[varOffset[code].+(1:3)],
    #                     )
    #                     push!(valueArray, value)
    #                 end
    #             end
    #             push!(inputs, IGFactor.InputValue(bg, valueArray))
    #         end
    #     end
    #     IGFactor.value(inputs)
    # end
    #
    # function ∇f!(g, xVal...)
    #     inputs = []
    #     #global knownCode, varOffset, x
    #     for (k, record) in enumerate(data)
    #         for (bg, prevAct, currAct) in record
    #             dwrtArray = Array{IGFactor.EvalDict,1}()
    #             for code in knownCode
    #                 for diffT in [prevAct[code][1], currAct[code][1]]
    #                     dwrt = CosSqr.dwrt(
    #                         diffT,
    #                         x[k],
    #                         x[varOffset[code].+(1:3)],
    #                         xVal[k],
    #                         xVal[varOffset[code].+(1:3)],
    #                     )
    #                     push!(dwrtArray, dwrt)
    #                 end
    #             end
    #             push!(inputs, IGFactor.InputDwrt(bg, dwrtArray))
    #         end
    #     end
    #     dwrt = IGFactor.dwrt(inputs)
    #     for (iX, varX) in enumerate(x)
    #         g[iX] = get(dwrt, varX, 0.0)
    #     end
    # end

    #construct data
    data = []
    dataTransactions = []
    for record in rawData
        (result, transactions) = recordToDiffT(record)
        push!(data, result)
        push!(dataTransactions, transactions)
    end
    #optimization
    JuMP.register(model, :f, nX, f, ∇f!)
    @NLobjective(model, Max, f(x...))
    #@load "x.jld2" x
    optimize!(model)
    xVal = fill(0.0, length(x))
    for i = 1:length(x)
        xVal[i] = value(x[i])
    end
    #statisticsIntervals(dataTransactions)
    @save "Results/data_preprocessing_$(maxIter).jld2" dataTransactions xVal
end
#optimize function second
#function optimizeParamsSecond()
    #println("at the very beginning")
    # raw data from uci diabetes
maxIter = 10
minSupp = 0.1
minConf = 0.2
#numF = 0
    #path = "/Users/hui/work/Programs/TemporalAsscoaitionRule20200723"
rawData = UCID.loadUCIDiabetes("/Users/hui/work/Programs/TemporalAsscoaitionRule20200901")
    # variables and symbols for duration scaling
knownCode = [33, 34, 35]
addCode = [65, 66, 67, 68, 69, 70, 71, 72]
allCode = [33, 34, 35, 65, 66, 67, 68, 69, 70, 71, 72]
nData = size(rawData, 1)
nX = nData + size(knownCode, 1) * 3
varOffset = Dict(33 => nData, 34 => nData + 3, 35 => nData + 6)
model = Model(with_optimizer(
    Ipopt.Optimizer,
    max_iter = maxIter,
    adaptive_mu_globalization = "never-monotone-mode",
))
# τ33_init = [0.5, 2.5, 7.5]
# τ34_init = [2, 7, 19]
# τ35_init = [3.5, 4, 31]
# τ33_init = [0.5, 2.0, 5.0]
# τ34_init = [2.0, 5.0, 12.0]
# τ35_init = [3.5, 15.0, 27.0]
τ33_init = [0.5, 4.0, 8.0]
τ34_init = [2.0, 10.0, 19.0]
τ35_init = [3.5, 15.0, 31.0]
function x0(i)
    if i <= nData
        1.0
    elseif i <= nData + 3
        τ33_init[i-nData]
    elseif i <= nData + 6
        τ34_init[i-nData-3]
    else
        τ35_init[i-nData-6]
    end
end
@variable(model, x[i = 1:nX] >= 0.001, start = x0(i))
for i = 1:nData
    @constraint(model, x[i] <= 3.0)
end
for code in knownCode
    @constraint(model, x[varOffset[code]+1] + 0.001 <= x[varOffset[code]+2])
    @constraint(model, x[varOffset[code]+2] + 0.001 <= x[varOffset[code]+3])
    @constraint(model, x[varOffset[code]+3] <= 2.0 * x0(varOffset[code] + 3))
end
@constraint(model, sum(x[1:nData]) == nData)
path = "/Users/hui/work/Programs/TemporalAsscoaitionRule20200901/Results"
function f(xVal...)
    #println("another xVal: ", xVal)
#global prexVal, preAvgSupport
#h = 0.0001
if prexVal == xVal
    preAvgSupport
else
    prexVal = xVal
    @save "data_preprocessing.jld2" dataTransactions xVal
    varOffset[code].+(1:3)s()
    @load "Results/Transactions_timeParameters.jld2" result
    tableHead = result[1]
    numCols = length(tableHead)
    colNameToColIndex = Dict()
    for iCol = 1:numCols
        colNameToColIndex[tableHead[iCol]] = iCol
    end
    numTransactions = length(result[2])
    for i = 1:length(freqSetList)
        for (key, val) in freqSetList[i]
            for transaction in result[2]
                freqSetList[i][key] = 0.0
                Δval = 1.0
                for freqItem in key
                    colName = freqItem[1]
                    itemLevel = freqItem[2]
                    colIndex = colNameToColIndex[colName]
                    colVal = transaction[colIndex]
                    if itemLevel - 1 < colVal <= itemLevel
                        Δval *= colVal - itemLevel + 1
                    elseif itemLevel < colVal < itemLevel + 1
                        Δval *= itemLevel + 1 - colVal
                    else
                        Δval = 0.0
                    end
                end
                freqSetList[i][key] += Δval
            end
        end
        for (key, val) in freqSetList[i]
            freqSetList[i][key] = val / numTransactions
        end
    end
    @load path*"FilteredRules" FilteredRules
    NumberOfFilteredRules = 0
    AvgSupport = 0.0
    AvgConfidence = 0.0
    AvgLift = 0.0
    for iFilteredRules = 1:length(FilteredRules)
        consequent = FilteredRules[iFilteredRules][6]
        numConsequent = length(consequent)
        antecedent = FilteredRules[iFilteredRules][5]
        rule_of_key = union(antecedent, consequent)
        support_of_rule = freqSetList[length(rule_of_key)][rule_of_key]
        support_of_antecedent = freqSetList[length(antecedent)][antecedent]
        support_of_consequent = freqSetList[numConsequent][Set{Tuple{
            String,
            Int64,
        }}(consequent)]
        Confidence_current = support_of_rule / support_of_antecedent
        Lift_current = support_of_rule / support_of_consequent

        NumberOfFilteredRules = NumberOfFilteredRules + 1
        AvgSupport = AvgSupport + support_of_rule
        AvgConfidence = AvgConfidence + Confidence_current
        AvgLift = AvgLift + Lift_current
    end
    if NumberOfFilteredRules == 0
        AvgSupport = 0.0
        AvgConfidence = 0.0
        AvgLift = 0.0
    else
        AvgSupport = AvgSupport / NumberOfFilteredRules
        AvgConfidence = AvgConfidence / NumberOfFilteredRules
        AvgLift = AvgLift / NumberOfFilteredRules
    end
    #println("f:AvgSupport = $AvgSupport")
    preAvgSupport = AvgSupport
    AvgSupport
end
end
function ∇f!(g, xVal...)
    for (iX, varX) in enumerate(x)
        function ff(xx)
            xxVal = [if i==iX xx else xVal[i] end for i = 1:nX]
            f(xxVal...)
        end
        g[iX] = central_fdm(5, 1)(ff, xVal[iX])
            #limit((f(iX+h) - f(iX))/ h, h, iX)
    end
end
if iOptimizer == 1
    JuMP.register(model, :f, nX, f, ∇f!)
    @NLobjective(model, Max, f(x...))
end
optimize!(model)
iOptimizer = iOptimizer + 1
end
# informationgain f and
# function f(xVal...)
#     #global numF, minSupp, minConf
#     #numF = numF + 1
#     #println("numF = $numF")
#     # adjustParams_generateTransactions()
#     # @load "Results/Transactions_timeParameters.jld2" result
#     # freqSetList = Apriori(result, minSupp)
#     # NumberOfRules = generate_TARules(
#     #     comparisonFilteredOutputRules,
#     #     freqSetList,
#     #     minSupp,
#     #     minConf,
#     # )
#     # AvgConfidence = filterRules(
#     #     comparisonFilteredOutputRules,
#     #     minSupp,
#     #     minConf,
#     # )
#     AvgConfidence = 0.0
#     @load path*"FilteredRules" FilteredRules
#
#     for iFilteredRules = 1: length(FilteredRules)
#         numConsequent = length(consequent)
#         antecedent = setdiff(key, consequent)
#         support_of_antecedent = freqSetList[i-numConsequent][antecedent]
#         support_of_consequent = freqSetList[numConsequent][Set{Tuple{String,Int64}}(consequent)]
#         Confidence_current = val / support_of_antecedent
#         Lift_current = val / support_of_consequent
#
#         #println("$(support_of_antecedent), $(Confidence_current), $(antecedent), $(consequent)")
#
#
#             #count_outputed_rules = count_outputed_rules + 1
#             AvgSupport = AvgSupport + val
#             AvgConfidence = AvgConfidence + Confidence_current
#             AvgLift = AvgLift + Lift_current
#     end
# end
# function ∇f!(g, xVal...)
#     h = 0.001
#     for (iX, varX) in enumerate(x)
#         g[iX] = central_fdm(5, 1)(f, iX)
#             #limit((f(iX+h) - f(iX))/ h, h, iX)
#     end
# end
    #println("before adjustParams_dataPreprocessing(2)")
#adjustParams_dataPreprocessing(1)
    #println("before adjustParams_generateTransactions(2)")
#adjustParams_generateTransactions(1)
    #println("after adjustParams_generateTransactions(2)")
    #@load "Results/Transactions_timeParameters_2.jld2" result
    #path = "/Users/hui/work/Programs/TemporalAsscoaitionRule20200723/Results/"
comparisonFilteredOutputRules = open(
    path*"comparisonFilteredOutputRules_ThreeMethods.txt",
    "w",
)

    #construct data
data = []
dataTransactions = []
    #print("before record-data")
for record in rawData
    (result, transactions) = recordToDiffT(record)
    push!(data, result)
    push!(dataTransactions, transactions)
end
    #optimization
    #@load "x.jld2" x
    #println("before optimize!")
for iOptimizer = 1:5
    xVal = fill(0.0, length(x))
    if iOptimizer > 1
        for i = 1:length(x)
            xVal[i] = value(x[i])
        end
    else
        for i = 1:length(x)
            xVal[i] = x0(i)
        end
    end
        #statisticsIntervals(dataTransactions)
    @save "Results/data_preprocessing.jld2" dataTransactions xVal
    adjustParams_generateTransactions()
    @load "Results/Transactions_timeParameters.jld2" result

    freqSetList = Apriori(result, minSupp)

    NumberOfRules = generate_TARules(
        comparisonFilteredOutputRules,
        freqSetList,
        minSupp,
        minConf,
    )

    AvgConfidence = filterRules(
        comparisonFilteredOutputRules,
        minSupp,
        minConf,
    )
    prexVal = nothing #fill(0.0, length(x))
    preAvgSupport = 0.0
    function f(xVal...)
        #println("another xVal: ", xVal)
    #global prexVal, preAvgSupport
    #h = 0.0001
    if prexVal == xVal
        preAvgSupport
    else
        prexVal = xVal
        @save "data_preprocessing.jld2" dataTransactions xVal
        adjustParams_generateTransactions()
        @load "Results/Transactions_timeParameters.jld2" result
        tableHead = result[1]
        numCols = length(tableHead)
        colNameToColIndex = Dict()
        for iCol = 1:numCols
            colNameToColIndex[tableHead[iCol]] = iCol
        end
        numTransactions = length(result[2])
        for i = 1:length(freqSetList)
            for (key, val) in freqSetList[i]
                for transaction in result[2]
                    freqSetList[i][key] = 0.0
                    Δval = 1.0
                    for freqItem in key
                        colName = freqItem[1]
                        itemLevel = freqItem[2]
                        colIndex = colNameToColIndex[colName]
                        colVal = transaction[colIndex]
                        if itemLevel - 1 < colVal <= itemLevel
                            Δval *= colVal - itemLevel + 1
                        elseif itemLevel < colVal < itemLevel + 1
                            Δval *= itemLevel + 1 - colVal
                        else
                            Δval = 0.0
                        end
                    end
                    freqSetList[i][key] += Δval
                end
            end
            for (key, val) in freqSetList[i]
                freqSetList[i][key] = val / numTransactions
            end
        end
        @load path*"FilteredRules" FilteredRules
        NumberOfFilteredRules = 0
        AvgSupport = 0.0
        AvgConfidence = 0.0
        AvgLift = 0.0
        for iFilteredRules = 1:length(FilteredRules)
            consequent = FilteredRules[iFilteredRules][6]
            numConsequent = length(consequent)
            antecedent = FilteredRules[iFilteredRules][5]
            rule_of_key = union(antecedent, consequent)
            support_of_rule = freqSetList[length(rule_of_key)][rule_of_key]
            support_of_antecedent = freqSetList[length(antecedent)][antecedent]
            support_of_consequent = freqSetList[numConsequent][Set{Tuple{
                String,
                Int64,
            }}(consequent)]
            Confidence_current = support_of_rule / support_of_antecedent
            Lift_current = support_of_rule / support_of_consequent

            NumberOfFilteredRules = NumberOfFilteredRules + 1
            AvgSupport = AvgSupport + support_of_rule
            AvgConfidence = AvgConfidence + Confidence_current
            AvgLift = AvgLift + Lift_current
        end
        if NumberOfFilteredRules == 0
            AvgSupport = 0.0
            AvgConfidence = 0.0
            AvgLift = 0.0
        else
            AvgSupport = AvgSupport / NumberOfFilteredRules
            AvgConfidence = AvgConfidence / NumberOfFilteredRules
            AvgLift = AvgLift / NumberOfFilteredRules
        end
        #println("f:AvgSupport = $AvgSupport")
        preAvgSupport = min(AvgSupport, AvgConfidence, AvgLift)
        #AvgSupport
    end
end
    function ∇f!(g, xVal...)
        for (iX, varX) in enumerate(x)
            function ff(xx)
                xxVal = [if i==iX xx else xVal[i] end for i = 1:nX]
                f(xxVal...)
            end
            g[iX] = central_fdm(5, 1)(ff, xVal[iX])
                #limit((f(iX+h) - f(iX))/ h, h, iX)
        end
    end
    if iOptimizer == 1
        JuMP.register(model, :f, nX, f, ∇f!)
        @NLobjective(model, Max, f(x...))
    end
    optimize!(model)
    iOptimizer = iOptimizer + 1
end
    #println("after optimize!")
xVal = fill(0.0, length(x))
for i = 1:length(x)
    xVal[i] = value(x[i])
end
    #statisticsIntervals(dataTransactions)
@save "Results/data_preprocessing.jld2" dataTransactions xVal
close(comparisonFilteredOutputRules)
#end
#println("before optimizeParamsSecond()")
#optimizeParamsSecond()
