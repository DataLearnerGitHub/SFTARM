include("ucid.jl")
include("aprioriDerivative_FTARM.jl")
include("cossqr.jl")
include("igfactor.jl")
include("process.jl")
include("generateTransactions_timeParameters_params.jl")

#include("aprioriDerivative_params.jl")
import Distributions: Uniform

using Dates
using JuMP
using Ipopt
using JLD2
using FiniteDifferences
# using LinearAlgebra
# using StatsBase
#global parameters
path = "/Users/hui/work/Programs/TemporalAsscoaitionRule20200901/"
SavePath = "Results/FTARMRandom/"
minSupp = 0.1
minConf= 0.5

# convert DateTime into propority of hours
function tToDiffT(t::DateTime, act::Dict{Int32,Tuple{DateTime,Float64}})
    result = Dict{Int32,Tuple{Float64,Float64}}()
    for code in keys(act)
        (refT, actValue) = act[code]
        @assert t >= refT
        diffT = (t - refT) / Millisecond(Hour(1))
        #result[code] = (diffT, actValue)
        weightedValue = actValue
        if weightedValue > 32
            weightedValue = 32
        end
        weightTime = 2 - weightedValue / 16
        result[code] = (weightTime * diffT, actValue)
    end
    result
end
# define a fuzzified blood glucose levels:
function bgLevel(x::Float64)
    if 40.0 <= x < 80.0
        2.0 - (80.0 - x) / 40.0
    elseif 80.0 <= x < 130.0
        2.0
    elseif 130.0 <= x < 300.0
        3.0 - (300.0 - x) / 170.0
    elseif x >= 300.0
        3.0
    else
        1.0
    end
end
function derivativeBgFuzzy(x::Float64)
    if x < -12.0
        -2.0
    elseif -12.0 <= x < -3.0
        -1.5 + 0.5(x + 3.0) / 9.0
    elseif  -3.0 <= x < -1.0
        -1.0 + 0.5(x + 1.0) / 2.0
    elseif -1.0 <= x < 1.0
        x
    elseif 2.5 > x >= 1.0
        1.0 + 0.5(x - 1.0) / 1.5
    elseif 11 > x >= 2.5
        1.5 + 0.5(x - 2.5) / 8.5
    else
        2.0
    end
end
function derivativeInFuzzy(x::Float64)
    if x < -1.0
        -2.0
    elseif -1.0 <= x < -0.1
        #-2.0 - x / 2.0
        -1.0 + (x + 0.1) / 0.9
    elseif -0.1 <= x < 0.1
        10x
    elseif 0.4 > x >= 0.1
        #1.0 + x / 0.4
        1.0 + 0.5(x -0.1) / 0.3
    elseif 1.0 > x >= 0.4
        1.5 + 0.5(x - 0.4) / 0.6
    else
        2.0
    end
end
# function derivativeBgFuzzy(x::Float64)
#     if x < -12.0
#         -2.0
#     elseif -12.0 <= x < -3.0
#         -2.0 - x / 24.0
#     elseif -3.0 <= x < -1.0
#         -1.5 - x / 6.0
#     elseif -1.0 <= x < 1.0
#         x
#     elseif 2.5 > x >= 1.0
#         1.0 + x / 5.0
#     elseif 11 > x >= 2.5
#         1.5 + x / 22.0
#     else
#         2.0
#     end
# end
# function derivativeInFuzzy(x::Float64)
#     if x < -1.0
#         -2.0
#     elseif -1.0 <= x < -0.1
#         -2.0 - x / 2.0
#     elseif -0.1 <= x < 0.1
#         10x
#     elseif 0.4 > x >= 0.1
#         1.0 + x / 0.4
#     elseif 1.0 > x >= 0.4
#         1.0 + x / 2.0
#     else
#         2.0
#     end
# end
function derivativeAct(curract::Dict{Int32,Tuple{DateTime,Float64}}, prevact::Dict{Int32,Tuple{DateTime,Float64}})
    currDerivativeAct = []
    for code in keys(curract)
        (currRefT, currActValue) = curract[code]
        (prevRefT, prevActValue) = prevact[code]
        if currRefT == prevRefT
            push!(currDerivativeAct, 0.0)
        else
            push!(
                currDerivativeAct,
                # (currActValue - prevActValue) /
                #                   ((currRefT - prevRefT) /
                #                    Millisecond(Hour(1))),
                derivativeInFuzzy((currActValue - prevActValue) /
                                  ((currRefT - prevRefT) /
                                   Millisecond(Hour(1)))),
            )
        end
    end
    Tuple(currDerivativeAct)
end
function derivativeAct(
    curract::Tuple{DateTime,Float64},
    prevact::Tuple{DateTime,Float64},
)
    (currRefT, currActValue) = curract
    (prevRefT, prevActValue) = prevact
    if currRefT == prevRefT
        0.0
    else
        # (currActValue - prevActValue) /
        #                   ((currRefT - prevRefT) / Millisecond(Hour(1)))
        derivativeBgFuzzy((currActValue - prevActValue) /
                          ((currRefT - prevRefT) / Millisecond(Hour(1))))
    end
end
# convert data record to diffT
function recordToDiffT(record::Array{UCID.Activity,1})
    result = []
    transactions = []
    dateTime0 = DateTime("1-1-0 0:0", "m-d-y H:M")
    nilActStat = (dateTime0, 0.0)
    prevprevAct = Dict{Int32,Tuple{DateTime,Float64}}(
        33 => nilActStat,
        34 => nilActStat,
        35 => nilActStat,
    )
    prevAct = Dict{Int32,Tuple{DateTime,Float64}}(
        33 => nilActStat,
        34 => nilActStat,
        35 => nilActStat,
    )
    currAct = Dict{Int32,Tuple{DateTime,Float64}}(
        33 => nilActStat,
        34 => nilActStat,
        35 => nilActStat,
    )
    currBgAct = nilActStat
    prevBgAct = nilActStat
    prevprevBgAct = nilActStat
    for act in record
        if act.code in keys(currAct)
            prevprevAct[act.code] = prevAct[act.code]
            prevAct[act.code] = currAct[act.code]
            currAct[act.code] = (act.dateTime, act.value)
        elseif 48 <= act.code <= 64
            currBgAct = (act.dateTime, act.value)

            push!(
                result,
                (
                 bgLevel(act.value),
                 tToDiffT(act.dateTime, prevAct),
                 tToDiffT(act.dateTime, currAct),
                ),
            )

            push!(
                transactions,
                (
                 bgLevel(act.value),
                 tToDiffT(act.dateTime, prevAct),
                 tToDiffT(act.dateTime, currAct),
                 derivativeAct(currBgAct, prevBgAct),
                 derivativeAct(prevBgAct, prevprevBgAct),
                 derivativeAct(currAct, prevAct),
                 derivativeAct(prevAct, prevprevAct),
                 # (DC33, DC34, DC35) = derivativeAct(currAct, prevAct),
                 # (DP33, DP34, DP35) = derivativeAct(prevAct, prevprevAct),
                ),
            )

            prevprevBgAct = prevBgAct
            prevBgAct = currBgAct
        end
    end
    (result, transactions)
end
# counting to find interval points for the equal amounts.
function statisticsIntervals(dataTransactions)
    # counting for minmum and maxmum
    numRows = length(dataTransactions)
    # for colId = 9:16
    #     column = [result[2][rowId][colId] for rowId = 1:numRows]
    #     println(colId, ",", min(column...), ",", max(column...))
    # end
    for colId = 9:16
        colVector = [dataTransactions[rowId][colId] for rowId = 1:numRows]
        println(colVector[1:3])
        sort!(colVector)
        colSpliters = colVector[Int32(floor(numRows / 5))*(1:4)]
        println("colSpliters of $(colId) = $(colSpliters)")
    end
end
#find feature's maximum and minimum
function min_max(code::Int, rawData)::Tuple{Float64,Float64}
    codeMax = Float64(-1000.0)
    codeMin = 100000.0
    for irawData = 1: length(rawData)
        for jrawData = 1: length(rawData[irawData])
            temprawData = rawData[irawData][jrawData]
            if temprawData.code == code
                if temprawData.value > codeMax
                    codeMax = temprawData.value
                end
                if temprawData.value < codeMin
                    codeMin = temprawData.value
                end
            end
        end

    end
    println("The maximum value of code $(code) is $(codeMax), while the minimum value of code $(code) is $(codeMin).")
    return (codeMax, codeMin)
end
function randomIntervals(code::Int, rawData)::Array{Float64,1}
    (Max, Min) = min_max(code, rawData)
    τ_init = sort(rand(Uniform(Min, Max), 3))
    #sample(Min: Max, 3, replace=false)
    return τ_init
end
function adjustParams_dataPreprocessing(comparisonFilteredOutputRules::IOStream, maxIter::Int, maxRandom::Int)
    # raw data from uci diabetes
    path = "/Users/hui/work/Programs/TemporalAsscoaitionRule20200901/"
    rawData = UCID.loadUCIDiabetes(path)
    # variables and symbols for duration scaling
    knownCode = [33, 34, 35]
    addCode = [65, 66, 67, 68, 69, 70, 71, 72]
    allCode = [33, 34, 35, 65, 66, 67, 68, 69, 70, 71, 72]
    nData = size(rawData, 1)
    nX = nData + size(knownCode, 1) * 3
    varOffset = Dict(33 => nData, 34 => nData + 3, 35 => nData + 6)
    # τ33_init = [0.5, 2.5, 7.5]
    # τ34_init = [2, 7, 19]
    # τ35_init = [3.5, 4, 31]
    # τ33_init = [2.0, 4.0, 9.0]
    # τ34_init = [3.5, 8.5, 20.5]
    # τ35_init = [3.0, 5.5, 32.5]
    τ33_init = []
    τ34_init = []
    τ35_init = []
    τ33_initBest = []
    τ34_initBest = []
    τ35_initBest = []
    resultBest = []
    preAvgSupport = 0.0

    function x0(i)
        if i <= nData
            1.0
        elseif i <= nData + 3
            τ33_init[i-nData]
        elseif i <= nData + 6
            τ34_init[i-nData-3]
        else
            τ35_init[i-nData-6]
        end
    end
    for iMaxRandom = 1:maxRandom
        model = Model(optimizer_with_attributes(
            Ipopt.Optimizer,
            "max_iter" => maxIter,
            "adaptive_mu_globalization" => "never-monotone-mode",
        ))
        τ33_init = randomIntervals(33, rawData)
        τ34_init = randomIntervals(34, rawData)
        τ35_init = randomIntervals(35, rawData)

        @variable(model, x[i = 1:nX] >= 0.001, start = x0(i))
        for i = 1:nData
            @constraint(model, x[i] <= 3.0)
        end
        for code in knownCode
            @constraint(model, x[varOffset[code]+1] + 0.001 <= x[varOffset[code]+2])
            @constraint(model, x[varOffset[code]+2] + 0.001 <= x[varOffset[code]+3])
            @constraint(
                model,
                x[varOffset[code]+3] <= 2.0 * x0(varOffset[code] + 3),
            )
        end
        @constraint(model, sum(x[1:nData]) == nData)
        data = []
        dataTransactions = []
        result = []
            #print("before record-data")
        for record in rawData
            (result, transactions) = recordToDiffT(record)
            push!(data, result)
            push!(dataTransactions, transactions)
        end
        xVal = fill(0.0, length(x))

        for i = 1:length(x)
            xVal[i] = x0(i)
        end
        xValBest = fill(0.0, length(x))
        prexVal = fill(0.0, length(x))
        result = adjustParams_generateTransactionsRandom(dataTransactions, xVal)
        #@load SavePath*"Transactions_timeParameters_FTARM.jld2" result
        if iMaxRandom <= 1
            @save SavePath*"data_preprocessing_FTARM.jld2" dataTransactions xVal
            @save SavePath*"Transactions_timeParameters_FTARM.jld2" result
        end
        freqSetList = Apriori(result, minSupp)
        # NumberOfRules = generate_TARules(
        #     #comparisonFilteredOutputRules,
        #     freqSetList,
        #     minSupp,
        #     minConf,
        # )
        #
        # AvgConfidence = filterRules(
        #     #comparisonFilteredOutputRules,
        #     minSupp,
        #     minConf,
        # )
        # define f ∇f
        function f(xVal...)
            #println("358xVal = $xVal")
            if typeof(xVal)<:Tuple{Array}
                xVal = xVal[1]
            end
            #println("another xVal: ", xVal)
        #global prexVal, preAvgSupport
        #h = 0.0001
            if prexVal == xVal
                preAvgSupport
            else
                prexVal = xVal
                #println("369xVal = $xVal")
                #@save "Results/data_preprocessing.jld2" dataTransactions xVal
                result = adjustParams_generateTransactionsRandom(dataTransactions, xVal)
                #@load "Results/Transactions_timeParameters.jld2" result
                freqSetList = Apriori(result, minSupp)
                (Rules, count_outputed_rules, AvgSupport, AvgConfidence, AvgLift) = generate_TARules(comparisonFilteredOutputRules,freqSetList, minSupp, minConf)
                (FilteredRules, NumberOfFilteredRules, AvgSupportFiltered, AvgConfidenceFiltered, AvgLiftFiltered) = filterRules(Rules, comparisonFilteredOutputRules, minSupp, minConf)
                # tableHead = result[1]
                # numCols = length(tableHead)
                # colNameToColIndex = Dict()
                # for iCol = 1:numCols
                #     colNameToColIndex[tableHead[iCol]] = iCol
                # end
                # numTransactions = length(result[2])
                # for i = 1:length(freqSetList)
                #     for (key, val) in freqSetList[i]
                #         for transaction in result[2]
                #             freqSetList[i][key] = 0.0
                #             Δval = 1.0
                #             for freqItem in key
                #                 colName = freqItem[1]
                #                 itemLevel = freqItem[2]
                #                 colIndex = colNameToColIndex[colName]
                #                 colVal = transaction[colIndex]
                #                 if itemLevel - 1 < colVal <= itemLevel
                #                     Δval *= colVal - itemLevel + 1
                #                 elseif itemLevel < colVal < itemLevel + 1
                #                     Δval *= itemLevel + 1 - colVal
                #                 else
                #                     Δval = 0.0
                #                 end
                #             end
                #             freqSetList[i][key] += Δval
                #         end
                #     end
                #     for (key, val) in freqSetList[i]
                #         freqSetList[i][key] = val / numTransactions
                #     end
                # end
                # @load path * "FilteredRules" FilteredRules
                # NumberOfFilteredRules = 0
                # AvgSupport = 0.0
                # AvgConfidence = 0.0
                # AvgLift = 0.0
                # for iFilteredRules = 1:length(FilteredRules)
                #     try
                #         consequent = FilteredRules[iFilteredRules][6]
                #         numConsequent = length(consequent)
                #         antecedent = FilteredRules[iFilteredRules][5]
                #         rule_of_key = union(antecedent, consequent)
                #
                #         support_of_rule = freqSetList[length(rule_of_key)][rule_of_key]
                #         support_of_antecedent = freqSetList[length(antecedent)][antecedent]
                #         support_of_consequent = freqSetList[numConsequent][Set{Tuple{
                #             String,
                #             Int64,
                #         }}(consequent)]
                #         Confidence_current = support_of_rule / support_of_antecedent
                #         Lift_current = support_of_rule / support_of_consequent
                #
                #         NumberOfFilteredRules = NumberOfFilteredRules + 1
                #         AvgSupport = AvgSupport + support_of_rule
                #         AvgConfidence = AvgConfidence + Confidence_current
                #         AvgLift = AvgLift + Lift_current
                #     catch
                #     end
                # end
                # if NumberOfFilteredRules == 0
                #     AvgSupport = 0.0
                #     AvgConfidence = 0.0
                #     AvgLift = 0.0
                # else
                #     AvgSupport = AvgSupport / NumberOfFilteredRules
                #     AvgConfidence = AvgConfidence / NumberOfFilteredRules
                #     AvgLift = AvgLift / NumberOfFilteredRules
                # end
            #println("f:AvgSupport = $AvgSupport")
                # preAvgSupport = AvgConfidence
                AvgConfidence
                #preAvgSupport = min(AvgSupport, AvgConfidence, AvgLift)
            end
        end
        function ∇f!(g, xVal...)
            if typeof(xVal)<:Tuple{Array}
                xVal = xVal[1]
            end
            for (iX, varX) in enumerate(x)
                function ff(xx)
                    xxVal = [if i == iX
                        xx
                    else
                        xVal[i]
                    end for i = 1:nX]
                    f(xxVal...)
                end
                g[iX] = central_fdm(5, 1)(ff, xVal[iX])
                    #limit((f(iX+h) - f(iX))/ h, h, iX)
            end
        end

        #optimization
        JuMP.register(model, :f, nX, f, ∇f!)
        @NLobjective(model, Max, f(x...))
        #@load "x.jld2" x
        optimize!(model)
        xVal = fill(0.0, length(x))
        for i = 1:length(x)
            xVal[i] = value(x[i])
        end
        #@save "Results/data_preprocessing.jld2" dataTransactions xVal
        # println("467xVal = $xVal")
        # println("xValBest = $xValBest")

        if iMaxRandom <= 1
            τ33_initBest = τ33_init
            τ34_initBest = τ34_init
            τ35_initBest = τ35_init
            resultMetrics = resultBest = result
            xValMetrics= xValBest = xVal
            @save SavePath*"data_preprocessing_TFARMMetrics.jld2" dataTransactions xValMetrics
            #result = adjustParams_generateTransactionsRandom(dataTransactions, xVal)
            @save SavePath*"Transactions_timeParameters_FTARMMetrics.jld2" resultMetrics
        elseif f(xVal) > f(xValBest)
                τ33_initBest = τ33_init
                τ34_initBest = τ34_init
                τ35_initBest = τ35_init
                resultBest = result
                xValBest = xVal
        end
        if iMaxRandom >= maxRandom
            println("τ33_initBest = $τ33_initBest; τ34_initBest = $τ34_initBest; τ35_initBest = $τ35_initBest")
            # xVal = xValBest
            # result = resultBest
            @save SavePath*"data_preprocessing_TFARMRandom.jld2" dataTransactions xValBest
            @save SavePath*"Transactions_timeParameters_FTARMRandom.jld2" resultBest

        end
    end
end
function generate_TARules(comparisonFilteredOutputRules,freqSetList, minSupp, minConf)::Tuple
    count_outputed_rules = 0
    AvgSupport = 0.0
    AvgConfidence = 0.0
    AvgLift = 0.0
    # count_rules_specials = 0
    #count_outputed_abnormal = 0
    Rules = []
    for i = length(freqSetList):-1:5
        #println("i=",i)
        for (key, val) in freqSetList[i]
            consequent = []
            for freqItem in key
                if freqItem[1] == "bgLevel" || freqItem[1] == "prevBgLevel" || freqItem[1] == "DcurrBgLevel"|| freqItem[1] == "DprevBgLevel"
                    push!(consequent, freqItem)
                end
            end
            # println(length(consequent))
            if length(consequent) == 0
                continue
            end
            numConsequent = length(consequent)
            antecedent = setdiff(key, consequent)
            support_of_antecedent = freqSetList[i-numConsequent][antecedent]
            support_of_consequent = freqSetList[numConsequent][Set{Tuple{String,Int64}}(consequent)]
            Confidence_current = val / support_of_antecedent
            Lift_current = val / support_of_consequent

            #println("$(support_of_antecedent), $(Confidence_current), $(antecedent), $(consequent)")

            if Confidence_current >= minConf
                count_outputed_rules = count_outputed_rules + 1
                AvgSupport = AvgSupport + val
                AvgConfidence = AvgConfidence + Confidence_current
                AvgLift = AvgLift + Lift_current
                # if consequent == Any[("bgLevel", 2)] || consequent == Any[("prevBgLevel", 2)] || consequent == Any[("bgLevel", 2), ("prevBgLevel", 2)] || consequent == Any[("prevBgLevel", 2), ("bgLevel", 2)]
                #     continue
                # end

                # if consequent != Any[("bgLevel", 2), ("prevBgLevel", 2)] && consequent != Any[("prevBgLevel", 2), ("bgLevel", 2)]
                #     count_outputed_abnormal += 1
                # end
                push!(Rules, (count_outputed_rules, val, Confidence_current, Lift_current, antecedent, consequent))
                # println(
                #     io,
                #     (
                #      "outputed_rules",
                #      count_outputed_rules,
                #      ": Support =",
                #      val,
                #      " Confidence=",
                #      Confidence_current,
                #      " Lift =",
                #      Lift_current,
                #      "    antecedent=",
                #      antecedent,
                #      "--->> consequent=",
                #      consequent,
                #     ),
                # )
                # println(outputRules, "$(count_outputed_rules), $(val), $(Confidence_current), $(Lift_current), $(antecedent)=>$(consequent)")
                # println(outputRules, replace(
                #     replace(
                #         "$(count_outputed_rules), $(val), $(Confidence_current), $(Lift_current), $(antecedent)=>$(consequent)",
                #         "Set(Tuple{String,Int64}" => "("
                #     ),
                #     "Any" => ""
                # ))
            end

        end
    end
    #  println(
    # #     "count_outputed_abnormal=",
    # #     count_outputed_abnormal,
    #      "    count_outputed_rules=",
    #      count_outputed_rules,
    #  )
    #close(io)
    #close(outputRules)
    @save SavePath*"RULES_$(minSupp)_$(minConf).jld2" Rules

    if count_outputed_rules == 0
        AvgSupport = 0.0
        AvgConfidence = 0.0
        AvgLift = 0.0
    else
        AvgSupport = AvgSupport / count_outputed_rules
        AvgConfidence = AvgConfidence / count_outputed_rules
        AvgLift = AvgLift / count_outputed_rules
    end
    println(comparisonFilteredOutputRules, "outputRules: count_outputed_rules=$count_outputed_rules, AvgSupport = $AvgSupport, AvgConfidence = $AvgConfidence, AvgLift = $AvgLift")
    println("outputRules: count_outputed_rules=$count_outputed_rules, AvgSupport = $AvgSupport, AvgConfidence = $AvgConfidence, AvgLift = $AvgLift")
    return (Rules, count_outputed_rules, AvgSupport, AvgConfidence, AvgLift)
end
# Further filtering Rules
function filterRules(Rules::Union{Array, Tuple}, comparisonFilteredOutputRules::IOStream, minSupp::Float64, minConf::Float64)::Union{Array, Tuple}
    NumberOfFilteredRules = 0
    AvgSupport = 0.0
    AvgConfidence = 0.0
    AvgLift = 0.0
    #@load path*"RULES_$(minSupp)_$(minConf).jld2" Rules
    FilteredOutputRules = open(SavePath*"FilteredOutputRules/FilteredOutputRules_$(minSupp)_$(minConf).txt", "w")
    println(
        FilteredOutputRules,
        "Order_outputed_rules, Support, Confidence, Lift, Rules",
    )
    FilteredRules = []
    for IRules = 1:length(Rules)
        itemsWith04 = []
        for item in Rules[IRules][5]
            if item[2] == 4 || item[2] == 0
                push!(itemsWith04, item)
            end
        end
        if length(Rules[IRules][5]) == length(itemsWith04)
            continue
        end
        consequent = Rules[IRules][6]
        if consequent == Any[("bgLevel", 2)] ||
           consequent == Any[("prevBgLevel", 2)] ||
           consequent == Any[("bgLevel", 2), ("prevBgLevel", 2)] ||
           consequent == Any[("prevBgLevel", 2), ("bgLevel", 2)]
            continue
        end
        push!(FilteredRules, Rules[IRules])
        NumberOfFilteredRules = NumberOfFilteredRules + 1
        AvgSupport = AvgSupport + Rules[IRules][2]
        AvgConfidence = AvgConfidence + Rules[IRules][3]
        AvgLift = AvgLift + Rules[IRules][4]
        println(
            FilteredOutputRules,
            "$(Rules[IRules][1]):: $(Rules[IRules][2]), $(Rules[IRules][3]), $(Rules[IRules][4]), $(Rules[IRules][5]) ==> $(Rules[IRules][6])",
        )
    end
    #println("saving filtered rules")
    @save SavePath*"FilteredRules" FilteredRules
    #println("filtered rules saved")
    close(FilteredOutputRules)
    if NumberOfFilteredRules == 0
        AvgSupport = 0.0
        AvgConfidence = 0.0
        AvgLift = 0.0
    else
        AvgSupport = AvgSupport / NumberOfFilteredRules
        AvgConfidence = AvgConfidence / NumberOfFilteredRules
        AvgLift = AvgLift / NumberOfFilteredRules
    end
    println(comparisonFilteredOutputRules, "FilteredRules: NumberOfFilteredRules=$NumberOfFilteredRules, AvgSupport = $AvgSupport, AvgConfidence = $AvgConfidence, AvgLift = $AvgLift")
    println("FilteredRules: NumberOfFilteredRules=$NumberOfFilteredRules, AvgSupport = $AvgSupport, AvgConfidence = $AvgConfidence, AvgLift = $AvgLift")
    #NumberOfFilteredRules
    AvgConfidence
    return (FilteredRules, NumberOfFilteredRules, AvgSupport, AvgConfidence, AvgLift)
end
comparisonFilteredOutputRules = open(SavePath*"comparisonFilteredOutputRules_minSupp($minSupp),minConf($minConf).txt", "w")
# statisticsIntervals（）
#iterate random intervals and xVal simultaneously
#adjustParams_dataPreprocessing(maxIter = 1, maxRandom = 2)
adjustParams_dataPreprocessing(comparisonFilteredOutputRules,1, 2)
close(comparisonFilteredOutputRules)
