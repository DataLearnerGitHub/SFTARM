module IGFactor
export EvalDict, InputDwrt, InputValue, value, dwrt
using JuMP
EvalDict = Dict{Union{Nothing,VariableRef},Float64}
struct InputDwrt
    measure::Float64
    actList::Array{EvalDict,1}
end
struct InputValue
    measure::Float64
    actList::Array{Float64,1}
end
DwrtSeqList = Array{Array{InputDwrt,1},1}
ValueSeqList = Array{Array{InputValue,1},1}

# dst += c * src
function addDwrt!(dst::EvalDict, src::EvalDict, c::Real = 1.0)
    for (wrt, value) in src
        if haskey(dst, wrt)
            dst[wrt] += c * value
        else
            dst[wrt] = c * value
        end
    end
end

# dst[key] += c * src
function addDwrt!(
    dst::Dict{Int32,EvalDict},
    key::Int32,
    src::EvalDict,
    c::Real = 1.0,
)
    if !haskey(dst, key)
        dst[key] = EvalDict()
    end
    addDwrt!(dst[key], src, c)
end

# derivatives of dst * (a * src + b)
# dst.gradient = dst.gradient * (a * src.value + b) +
#               dst.value * a * src.gradient
# dst.value = src.value * (a * src.value + b)
function mulDwrt!(dst::EvalDict, a::Real, src::EvalDict, b::Real)
    dstValue = dst[nothing]
    srcValue = src[nothing]
    dst[nothing] = dstValue * (a * srcValue + b)
    for wrt in setdiff(keys(dst), [nothing])
        dst[wrt] *= a * srcValue + b
    end
    for wrt in setdiff(keys(src), [nothing])
        dst[wrt] = get(dst, wrt, 0.0) + dstValue * a * src[wrt]
    end
end

function validPatterns(record::InputValue)
    validActID = []
    patternMembership = Dict{Array{Int32,1},Float64}()
    for (i, act) in enumerate(record.actList)
        if act >= 4.0
            continue
        end
        push!(validActID, i)
    end
    m = size(validActID, 1)
    n = 2^m
    for j = 1:n
        valid = true
        indices = Array{Int32,1}(undef, m)
        value = 1.0
        for k = 1:m
            act = record.actList[validActID[k]]
            lohi = ((j - 1) >>> k) & 1
            low = Int32(floor(act))
            high = low + 1
            if lohi == 0
                indices[k] = low
                value *= high - act
            else
                if act == low
                    valid = false
                    break
                end
                indices[k] = high
                value *= act - low
            end
        end
        if valid
            patternMembership[indices] = value
        end
    end
    validActID, patternMembership
end

function validPatterns(record::InputDwrt)
    validActID = []
    patternMembership = Dict{Array{Int32,1},EvalDict}()
    for (i, act) in enumerate(record.actList)
        if act[nothing] >= 4.0
            continue
        end
        push!(validActID, i)
    end
    m = size(validActID, 1)
    n = 2^m
    for j = 1:n
        valid = true
        indices = Array{Int32,1}(undef, m)
        dwrt = EvalDict(nothing => 1.0)
        for k = 1:m
            act = record.actList[validActID[k]]
            lohi = ((j - 1) >>> k) & 1
            low = Int32(floor(act[nothing]))
            high = low + 1
            if lohi == 0
                indices[k] = low
                mulDwrt!(dwrt, -1.0, act, high)
            else
                if act[nothing] == low
                    valid = false
                    break
                end
                indices[k] = high
                mulDwrt!(dwrt, 1.0, act, -low)
            end
        end
        if valid
            patternMembership[indices] = dwrt
        end
    end
    validActID, patternMembership
end

function inputTree(inputs)
    result = Dict{Array{Int32,1},Dict{Array{Int32,1},Array{Any,1}}}()
    for meas in inputs

        IDs, patterns = validPatterns(meas)
        if !haskey(result, IDs)
            result[IDs] = Dict()
        end
        for p in keys(patterns)
            if !haskey(result[IDs], p)
                result[IDs][p] = []
            end
            push!(result[IDs][p], (patterns[p], meas.measure))
        end
    end
    result
end

function value(inputs)
    result = 0.0
    tree = inputTree(inputs)
    for actIDs in keys(tree)
        for actPatterns in keys(tree[actIDs])
            sumI = 0.0
            sumIJ = Dict{Int32,Float64}()

            for measure in tree[actIDs][actPatterns]
                # each measure is a tuple (membvalue, measLevel)
                # the membvalue in the function value of membership
                membvalue = measure[1]
                measLevel = measure[2]

                # update sumI
                sumI += membvalue

                # update sumIJ
                if measLevel == round(measLevel)
                    key = Int32(measLevel)
                    sumIJ[key] = get(sumIJ, key, 0.0) + membvalue
                else
                    keyLow = Int32(floor(measLevel))
                    keyHigh = Int32(keyLow + 1)
                    sumIJ[keyLow] = get(sumIJ, keyLow, 0.0) +
                                    membvalue * (keyHigh - measLevel)
                    sumIJ[keyHigh] = get(sumIJ, keyHigh, 0.0) +
                                     membvalue * (measLevel - keyLow)
                end
            end

            if !isempty(sumIJ)
                # add to result from dwrtSumIJ
                for valueIJ in values(sumIJ)
                    result += valueIJ * log(valueIJ)
                end

                # add to result from dwrtSumI
                result -= sumI * log(sumI)
            end
        end
    end
    result
end

function dwrt(inputs)
    result = EvalDict(nothing => 0.0)
    tree = inputTree(inputs)
    for actIDs in keys(tree)
        for actPatterns in keys(tree[actIDs])
            dwrtSumI = EvalDict()
            dwrtSumIJ = Dict{Int32,EvalDict}()

            for measure in tree[actIDs][actPatterns]
                # each measure is a tuple (membdwrt, measLevel)
                # the membdwrt in the partial derivatives of membership
                membdwrt = measure[1]
                measLevel = measure[2]

                # update dwrtSumI
                addDwrt!(dwrtSumI, membdwrt)

                # update dwrtSumIJ
                if measLevel == round(measLevel)
                    addDwrt!(dwrtSumIJ, Int32(measLevel), membdwrt)
                else
                    keyLow = Int32(floor(measLevel))
                    keyHigh = Int32(keyLow + 1)
                    addDwrt!(dwrtSumIJ, keyLow, membdwrt, keyHigh - measLevel)
                    addDwrt!(dwrtSumIJ, keyHigh, membdwrt, measLevel - keyLow)
                end
            end

            # add to result from dwrtSumIJ
            for dwrtIJ in values(dwrtSumIJ)
                valueIJ = dwrtIJ[nothing]
                result[nothing] += valueIJ * log(valueIJ)
                for (wrt, dwrt) in dwrtIJ
                    if wrt != nothing
                        if haskey(result, wrt)
                            result[wrt] += dwrt * (log(valueIJ) + 1.0)
                        else
                            result[wrt] = dwrt * (log(valueIJ) + 1.0)
                        end
                    end
                end
            end

            # add to result from dwrtSumI
            valueI = dwrtSumI[nothing]
            result[nothing] -= valueI * log(valueI)
            for (wrt, dwrt) in dwrtSumI
                if wrt != nothing
                    if haskey(result, wrt)
                        result[wrt] -= dwrt * (log(valueI) + 1.0)
                    else
                        result[wrt] = -dwrt * (log(valueI) + 1.0)
                    end
                end
            end
        end
    end
    result
end

end
