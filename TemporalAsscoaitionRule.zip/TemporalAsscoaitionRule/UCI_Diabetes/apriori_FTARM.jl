using JLD2

FreqItemType = Tuple{String,Int}
FreqSetType = Set{FreqItemType}
FreqCountDict = Dict{FreqSetType,Float64}
function Apriori(result, minSupp)
end
@load "002.jld2" result
freqSetList = Apriori(result, 0.01)
