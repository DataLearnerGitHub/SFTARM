include("ucid.jl")
include("process.jl")
#using Dates
# raw data from uci diabetes
function FS_insulin_dose()
path= "/Users/zhenghui/Movies/Temporal_Asscoaition_rule/"
rawData = UCID.loadUCIDiabetes(path)
normalization()
io = open(path*"002.log", "w")
for (k, record) in enumerate(rawData)
    for code in [33,34,35]
        sum_value = 0.0
        sum_number = 0
        for record_index in record
            if record_index.code == code
                sum_value += record_index.value
                sum_number += 1
            end
        end
        if sum_number > 0 && sum_value > 0
            sum_value_avg = sum_value / sum_number
            for record_index in record
                value = 0.0
                if record_index.code == code
                    value = record_index.value / sum_value_avg
                    push!(result, (record_index.dateTime, record_index.code, value))
                else
                    push!(result, (record_index.dateTime, record_index.code, record_index.value))
                end

            end
        end
        println(
            io,
            "The $k record--- sum_value_$code = $sum_value, sum_number_$code = $sum_number",
        )
    end
end
close(io)
end
function DATAPROCESSING()
    path= "/Users/zhenghui/Movies/Temporal_Asscoaition_rule/"
    #VirusData =
    #rawData = UCID.loadUCIDiabetes(path)
    io_matrix = open(path*"matrix.csv", "w")
    io = open(path*"seqDistance", "r")
    Selected_Data = []
    int i = 0
    while (s = readline(io); s ≠ "")
        ss = split(s, ",")
        Selected_Data[i][0] = ss[3]
        Selected_Data[i][1] = ss[4]
        #push!(newRecord, Activity(dateTime, code, value))
        i = i + 1
    end
println(Selected_Data)
distance[]
for(int j = 0; j < i; j++)
    for (int t = 0; t < i; t++)
        if(Selected_Data[j][0] == Selected_Data[t][0])
            distance[i][j] = 0
        else
            distance[i][j] = 0.5
        end
        distance[i][j] = distance[i][j] + (Selected_Data[j][1] - Selected_Data[t][1])/200
    end
end
close(io)
close(io_matrix)
end
DATAPROCESSING()
#FS_insulin_dose()
# nPos = 0
# nNeg = 0
#
# for (k, record) in enumerate(rawData)
#     mean = 0.0
#     n = 0
#     for act in record
#         if 48 <= act.code <= 64
#             mean += act.value
#             n += 1
#         end
#     end
#     mean /= n
#
#     acts_prev_day = []
#     acts_curr_day = []
#
#     for act in record
#         if isempty(acts_curr_day)
#             push!(acts_curr_day, act)
#         else
#             if day(acts_curr_day[end].dateTime) != day(act.dateTime)
#                 sum_BG_prev = 0.0
#                 sum_BG_n_prev = 0
#                 sum_insulin_prev = 0.0
#                 sum_insulin_curr = 0.0
#                 sum_BG_curr = 0.0
#                 sum_BG_n_curr = 0
#                 sum_BG_neg_n_prev = 0
#                 sum_BG_pos_n_prev = 0
#                 sum_insulin_neg_n_curr = 0
#                 sum_insulin_pos_n_curr = 0
#                 sum_insulin_prev_33 = 0.0
#                 sum_insulin_prev_34 = 0.0
#                 sum_insulin_prev_35 = 0.0
#                 sum_insulin_n_prev_33 = 0
#                 sum_insulin_n_prev_34 = 0
#                 sum_insulin_n_prev_35 = 0
#                 sum_insulin_curr_33 = 0.0
#                 sum_insulin_curr_34 = 0.0
#                 sum_insulin_curr_35 = 0.0
#                 sum_insulin_n_curr_33 = 0
#                 sum_insulin_n_curr_34 = 0
#                 sum_insulin_n_curr_35 = 0
#                 for act_prev in acts_prev_day
#                     if 48 <= act_prev.code <= 64
#                         sum_BG_prev += act_prev.value
#                         sum_BG_n_prev += 1
#                         if act_prev.value <= mean
#                             sum_BG_neg_n_prev += 1
#                         else
#                             sum_BG_pos_n_prev += 1
#                         end
#                     end
#                     if 33 <= act_prev.code <= 35
#                         sum_insulin_prev += act_prev.value
#                         if act_prev.code == 33
#                             sum_insulin_n_prev_33 += act_prev.value
#                             sum_insulin_n_prev_33 += 1
#                         elseif act_prev.code == 34
#                             sum_insulin_n_prev_34 += act_prev.value
#                             sum_insulin_n_prev_34 += 1
#                         elseif act_prev.code == 35
#                             sum_insulin_n_prev_35 += act_prev.value
#                             sum_insulin_n_prev_35 += 1
#                         end
#                     end
#                 end
#
#                 for act_curr in acts_curr_day
#                     if 48 <= act_curr.code <= 64
#                         sum_BG_curr += act_curr.value
#                         sum_BG_n_curr += 1
#                     end
#
#                     if 33 <= act_curr.code <= 35
#                         sum_insulin_curr += act_curr.value
#                         if act_curr.code == 33
#                             sum_insulin_n_curr_33 += act_curr.value
#                             sum_insulin_n_curr_33 += 1
#                         elseif act_curr.code == 34
#                             sum_insulin_n_curr_34 += act_curr.value
#                             sum_insulin_n_curr_34 += 1
#                         elseif act_curr.code == 35
#                             sum_insulin_n_curr_35 += act_curr.value
#                             sum_insulin_n_curr_35 += 1
#                         end
#                     end
#                 end
#
#                 if !isempty(acts_prev_day)
#                     mean_BG_prev = sum_BG_prev / sum_BG_n_prev
#                     mean_BG_curr = sum_BG_curr / sum_BG_n_curr
#                     date_prev = Date(acts_prev_day[1].dateTime)
#                     date_curr = Date(acts_curr_day[1].dateTime)
#                     sum_insulin_n_curr_33 = max(sum_insulin_n_curr_33, 1)
#                     sum_insulin_n_curr_34 = max(sum_insulin_n_curr_34, 1)
#                     sum_insulin_n_curr_35 = max(sum_insulin_n_curr_35, 1)
#                     sum_insulin_n_prev_33 = max(sum_insulin_n_prev_33, 1)
#                     sum_insulin_n_prev_34 = max(sum_insulin_n_prev_34, 1)
#                     sum_insulin_n_prev_35 = max(sum_insulin_n_prev_35, 1)
#                     pos_or_neg_33 = (sum_insulin_curr_33 /
#                                      sum_insulin_n_curr_33) -
#                                     (sum_insulin_prev_33 /
#                                      sum_insulin_n_prev_33) > 0
#                     pos_or_neg_34 = (sum_insulin_curr_34 /
#                                      sum_insulin_n_curr_34) -
#                                     (sum_insulin_prev_34 /
#                                      sum_insulin_n_prev_34) > 0
#                     pos_or_neg_35 = (sum_insulin_curr_35 /
#                                      sum_insulin_n_curr_35) -
#                                     (sum_insulin_prev_35 /
#                                      sum_insulin_n_prev_35) > 0
#                     count_insulin_pos_or_neg = ((pos_or_neg_33 &&
#                                                  pos_or_neg_34) ||
#                                                 (pos_or_neg_33 &&
#                                                  pos_or_neg_35) ||
#                                                 (pos_or_neg_35 &&
#                                                  pos_or_neg_34))
#                     insulin_pos_or_neg = (sum_BG_pos_n_prev >= sum_BG_neg_n_prev) *
#                                          (pos_or_neg_33) > 0
#                     pos_or_neg = (sum_BG_pos_n_prev - sum_BG_neg_n_prev) *
#                                  (sum_insulin_curr - sum_insulin_prev) > 0
#                     println(
#                         io,
#                         "$insulin_pos_or_neg---",
#                         "$pos_or_neg, ",
#                         "$date_prev ",
#                         "mean_BG_prev = $mean_BG_prev, ",
#                         "sum_insulin_prev = $sum_insulin_prev",
#                         ", $date_curr ",
#                         "mean_BG_curr = $mean_BG_curr, ",
#                         "sum_insulin_curr = $sum_insulin_curr",
#                     )
#                     global nPos, nNeg
#                     if pos_or_neg
#                         nPos += 1
#                     else
#                         nNeg += 1
#                     end
#                 end
#
#                 acts_prev_day = copy(acts_curr_day)
#                 acts_curr_day = [act]
#             else
#                 push!(acts_curr_day, act)
#             end
#         end
#     end
#
#
#     # for act in record
#     #     if 48 <= act.code <= 64
#     #         if act.value <= mean
#     #             nLow += 1
#     #         else
#     #             nHigh +=1
#     #         end
#     #         ###
#     #     #else if 180 <= act.code <= 200
#     #         #push!(a, act.value)
#     #     end
#     # end
#     # println("record $k: mean = $mean, nLow = $nLow, nHigh = $nHigh")
# end
#
# close(io)
#
# println("nPos = $nPos, nNeg = $nNeg")
