module UCID

using Printf
using Dates

export Activity, loadUCIDiabetes

mutable struct Activity
    dateTime::DateTime
    code::Int32
    value::Float64
end

function loadUCIDiabetes(dataPath::String)
    result = Array{Array{Activity,1},1}()
    dateFormat = DateFormat("m-d-y H:M")
    for fileNo = 1:70
        newRecord = Array{Activity,1}()
        fileName = @sprintf("%s/data/data-%02d", dataPath, fileNo)
        io = open(fileName, "r")
        while (s = readline(io); s ≠ "")
            ss = split(s)
            dateTime = DateTime(ss[1] * " " * ss[2], dateFormat)
            code = parse(Int32, ss[3])
            # NaN means not a number
            value = NaN
            try
                value = parse(Float64, ss[4])
            catch e
                continue
            end
            push!(newRecord, Activity(dateTime, code, value))
        end
        close(io)
        recordLt(x, y) = x.dateTime < y.dateTime
        push!(result, sort(newRecord, lt = recordLt))
    end
    result
end

end
