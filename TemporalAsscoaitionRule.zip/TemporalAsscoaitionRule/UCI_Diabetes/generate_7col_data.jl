using JLD2
include("cossqr.jl")
@load "001.jld2" data xVal
v_cs = xVal[1:70]
v_τ33 = (xVal[71], xVal[72], xVal[73])
v_τ34 = (xVal[74], xVal[75], xVal[76])
v_τ35 = (xVal[77], xVal[78], xVal[79])
v_τ = Dict(33 => v_τ33, 34 => v_τ34, 35 => v_τ35)
ItemType = Tuple{
    Float64,
    Dict{Int32,Tuple{Float64,Float64}},
    Dict{Int32,Tuple{Float64,Float64}},
}

function colValue(
    item::ItemType,
    i_c::Int,
    code::Int,
    isCurrent::Bool,
    v_cs::Array{Float64,1},
    v_τ::Dict{Int64,Tuple{Float64,Float64,Float64}},
)
    t = item[if isCurrent
        3
    else
        2
    end][code][1]
    v_c = v_cs[i_c]
    CosSqr.value(t, v_c, v_τ[code])
end

function getRow(
    item::ItemType,
    i_c::Int,
    v_cs::Array{Float64,1},
    v_τ::Dict{Int64,Tuple{Float64,Float64,Float64}},
    prevBgLevel::Float64,
)
    (
     item[1],
     prevBgLevel,
     colValue(item, i_c, 33, true, v_cs, v_τ),
     colValue(item, i_c, 34, true, v_cs, v_τ),
     colValue(item, i_c, 35, true, v_cs, v_τ),
     colValue(item, i_c, 33, false, v_cs, v_τ),
     colValue(item, i_c, 34, false, v_cs, v_τ),
     colValue(item, i_c, 35, false, v_cs, v_τ),
    )
end

function getTable(
    data::Array{Any,1},
    v_cs::Array{Float64,1},
    v_τ::Dict{Int64,Tuple{Float64,Float64,Float64}},
)
    result = []

    for (i_c, record) in enumerate(data)
        prevBgLevel = 2.0
        for item in record
            push!(result, getRow(item, i_c, v_cs, v_τ, prevBgLevel))
            prevBgLevel = item[1]
        end
    end
    result = (("bgLevel", "prevBgLevel", "curr33", "curr34", "curr35", "prev33", "prev34", "prev35"),
        result)
end

result = getTable(data, v_cs, v_τ)
@save "002.jld2" result
