include("ucid.jl")
include("cossqr.jl")
include("igfactor.jl")
include("process.jl")

using StatsBase

using Dates
using JuMP
using Ipopt
using JLD2

# raw data from uci diabetes

path= "/Users/hui/work/Programs/TemporalAsscoaitionRule20200901"
rawData = UCID.loadUCIDiabetes(path)

# variables and symbols for duration scaling
# 33[0,344] 34[1,388] 35[3.0,30]
knownCode = [33, 34, 35]
addCode = [65, 66, 67, 68, 69, 70, 71, 72]
allCode = [33, 34, 35, 65, 66, 67, 68, 69, 70, 71, 72]

nData = size(rawData, 1)
nX = nData + size(knownCode, 1) * 3
varOffset = Dict(33 => nData, 34 => nData + 3, 35 => nData + 6)
model = Model(with_optimizer(
    Ipopt.Optimizer,
    max_iter = 10,
    adaptive_mu_globalization = "never-monotone-mode",
))
# τ33_init = [0.5, 2.5, 7.5]
# τ34_init = [2, 7, 19]
# τ35_init = [3.5, 4, 31]
τ33_init = [0.5, 4.0, 8.0]
τ34_init = [2.0, 10.0, 19.0]
τ35_init = [3.5, 15.0, 31.0]
# τ33_init = [0.5, 2, 5]
# τ34_init = [2, 5, 12]
# τ35_init = [3.5, 15, 27]
function x0(i)
    if i <= nData
        1.0
    elseif i <= nData + 3
        τ33_init[i-nData]
    elseif i <= nData + 6
        τ34_init[i-nData-3]
    else
        τ35_init[i-nData-6]
    end
end
@variable(model, x[i = 1:nX] >= 0.001, start = x0(i))
for i = 1:nData
    @constraint(model, x[i] <= 3.0)
end
for code in knownCode
    @constraint(model, x[varOffset[code]+1] + 0.001 <= x[varOffset[code]+2])
    @constraint(model, x[varOffset[code]+2] + 0.001 <= x[varOffset[code]+3])
    @constraint(model, x[varOffset[code]+3] <= 2.0 * x0(varOffset[code] + 3))
end
@constraint(model, sum(x[1:nData]) == nData)
# convert DateTime into propority of hours
function tToDiffT(t::DateTime, act::Dict{Int32,Tuple{DateTime,Float64}})
    result = Dict{Int32,Tuple{Float64,Float64}}()
    for code in keys(act)
        (refT, actValue) = act[code]
        @assert t >= refT
        diffT = (t - refT) / Millisecond(Hour(1))
        weightedValue = actValue
        if weightedValue > 32
            weightedValue = 32
        end
        weightTime = 2 - weightedValue / 16
        result[code] = (weightTime * diffT, actValue)
    end
    result
end

# define a fuzzified blood glucose levels:
function bgLevel(x::Float64)
    if 40.0 <= x < 80.0
        2.0 - (80.0 - x) / 40.0
    elseif 80.0 <= x < 130.0
        2.0
    elseif 130.0 <= x < 300.0
        3.0 - (300.0 - x) / 170.0
    elseif x >= 300.0
        3.0
    else
        1.0
    end
end
function derivativeBgFuzzy(x::Float64)
    if x < -12.0
        -2.0
    elseif -12.0 <= x < -3.0
        -1.5 + 0.5(x + 3.0) / 9.0
    elseif  -3.0 <= x < -1.0
        -1.0 + 0.5(x + 1.0) / 2.0
    elseif -1.0 <= x < 1.0
        x
    elseif 2.5 > x >= 1.0
        1.0 + 0.5(x - 1.0) / 1.5
    elseif 11 > x >= 2.5
        1.5 + 0.5(x - 2.5) / 8.5
    else
        2.0
    end
end
function derivativeInFuzzy(x::Float64)
    if x < -1.0
        -2.0
    elseif -1.0 <= x < -0.1
        #-2.0 - x / 2.0
        -1.0 + (x + 0.1) / 0.9
    elseif -0.1 <= x < 0.1
        10x
    elseif 0.4 > x >= 0.1
        #1.0 + x / 0.4
        1.0 + 0.5(x -0.1) / 0.3
    elseif 1.0 > x >= 0.4
        1.5 + 0.5(x - 0.4) / 0.6
    else
        2.0
    end
end
# function derivativeBgFuzzy(x::Float64)
#     if x < -12.0
#         -2.0
#     elseif -12.0 <= x < -1.0
#         -2.0 - x / 12.0
#     elseif -1.0 <= x < 1.0
#         x
#     elseif 11 > x >= 1.0
#         1.0 + x / 11.0
#     else
#         2.0
#     end
# end
# function derivativeInFuzzy(x::Float64)
#     if x < -2.0
#         -2.0
#     elseif -2.0 <= x < -1.0
#         x
#     elseif -1.0 <= x < 1.0
#         x
#     elseif 2.0 > x > 1.0
#         x
#     else
#         2.0
#     end
# end
function derivativeAct(
    curract::Dict{Int32,Tuple{DateTime,Float64}},
    prevact::Dict{Int32,Tuple{DateTime,Float64}},
)
    currDerivativeAct = []
    for code in keys(curract)
        (currRefT, currActValue) = curract[code]
        (prevRefT, prevActValue) = prevact[code]
        if currRefT == prevRefT
            push!(currDerivativeAct, 0.0)
        else
            push!(
                currDerivativeAct,
                # (currActValue - prevActValue) /
                #                   ((currRefT - prevRefT) /
                #                    Millisecond(Hour(1))),
                derivativeInFuzzy((currActValue - prevActValue) /
                                  ((currRefT - prevRefT) /
                                   Millisecond(Hour(1)))),
            )
        end
    end
    Tuple(currDerivativeAct)
end
function derivativeAct(
    curract::Tuple{DateTime,Float64},
    prevact::Tuple{DateTime,Float64},
)
    (currRefT, currActValue) = curract
    (prevRefT, prevActValue) = prevact
    if currRefT == prevRefT
        0.0
    else
        # (currActValue - prevActValue) /
        #                   ((currRefT - prevRefT) / Millisecond(Hour(1)))
        derivativeBgFuzzy((currActValue - prevActValue) /
                          ((currRefT - prevRefT) / Millisecond(Hour(1))))
    end
end
# convert data record to diffT
function recordToDiffT(record::Array{UCID.Activity,1})
    result = []
    transactions = []
    dateTime0 = DateTime("1-1-0 0:0", "m-d-y H:M")
    nilActStat = (dateTime0, 0.0)
    prevprevAct = Dict{Int32,Tuple{DateTime,Float64}}(
        33 => nilActStat,
        34 => nilActStat,
        35 => nilActStat,
    )
    prevAct = Dict{Int32,Tuple{DateTime,Float64}}(
        33 => nilActStat,
        34 => nilActStat,
        35 => nilActStat,
    )
    currAct = Dict{Int32,Tuple{DateTime,Float64}}(
        33 => nilActStat,
        34 => nilActStat,
        35 => nilActStat,
    )
    currBgAct = nilActStat
    prevBgAct = nilActStat
    prevprevBgAct = nilActStat
    for act in record
        if act.code in keys(currAct)
            prevprevAct[act.code] = prevAct[act.code]
            prevAct[act.code] = currAct[act.code]
            currAct[act.code] = (act.dateTime, act.value)
        elseif 48 <= act.code <= 64
            currBgAct = (act.dateTime, act.value)

            push!(
                result,
                (
                 bgLevel(act.value),
                 tToDiffT(act.dateTime, prevAct),
                 tToDiffT(act.dateTime, currAct),
                ),
            )

            push!(
                transactions,
                (
                 bgLevel(act.value),
                 tToDiffT(act.dateTime, prevAct),
                 tToDiffT(act.dateTime, currAct),
                 derivativeAct(currBgAct, prevBgAct),
                 derivativeAct(prevBgAct, prevprevBgAct),
                 derivativeAct(currAct, prevAct),
                 derivativeAct(prevAct, prevprevAct),
                 # (DC33, DC34, DC35) = derivativeAct(currAct, prevAct),
                 # (DP33, DP34, DP35) = derivativeAct(prevAct, prevprevAct),
                ),
            )

            prevprevBgAct = prevBgAct
            prevBgAct = currBgAct
        end
    end
    (result, transactions)
end

data = []
dataTransactions = []
for record in rawData
    (result, transactions) = recordToDiffT(record)
    push!(data, result)
    push!(dataTransactions, transactions)
end
function f(xVal...)
    inputs = []
    global knownCode, varOffset
    for (k, record) in enumerate(data)
        for (bg, prevAct, currAct) in record
            valueArray = Array{Float64,1}()
            for code in knownCode
                for diffT in [prevAct[code][1], currAct[code][1]]
                    value = CosSqr.value(
                        diffT,
                        xVal[k],
                        xVal[ varOffset[code].+(1:3)],
                    )
                    push!(valueArray, value)
                end
            end
            push!(inputs, IGFactor.InputValue(bg, valueArray))
        end
    end
    IGFactor.value(inputs)
end

function ∇f!(g, xVal...)
    inputs = []
    global knownCode, varOffset, x
    for (k, record) in enumerate(data)
        for (bg, prevAct, currAct) in record
            dwrtArray = Array{IGFactor.EvalDict,1}()
            for code in knownCode
                for diffT in [prevAct[code][1], currAct[code][1]]
                    dwrt = CosSqr.dwrt(
                        diffT,
                        x[k],
                        x[varOffset[code].+(1:3)],
                        xVal[k],
                        xVal[varOffset[code].+(1:3)],
                    )
                    push!(dwrtArray, dwrt)
                end
            end
            push!(inputs, IGFactor.InputDwrt(bg, dwrtArray))
        end
    end
    dwrt = IGFactor.dwrt(inputs)
    for (iX, varX) in enumerate(x)
        g[iX] = get(dwrt, varX, 0.0)
    end
end
# counting to find interval points for the equal amounts.
function statisticsIntervals(dataTransactions)
    # counting for minmum and maxmum
    numRows = length(dataTransactions)
    # for colId = 9:16
    #     column = [result[2][rowId][colId] for rowId = 1:numRows]
    #     println(colId, ",", min(column...), ",", max(column...))
    # end
    for colId = 9:16
        colVector = [dataTransactions[rowId][colId] for rowId = 1:numRows]
        println(colVector[1:3])
        sort!(colVector)
        colSpliters = colVector[Int32(floor(numRows/5))*(1:4)]
        println("colSpliters of $(colId) = $(colSpliters)")
    end
end
function min_max(code::Int, rawData)::Tuple{Float64,Float64}
    codeMax = Float64(-1000.0)
    codeMin = 100000.0
    for irawData = 1: length(rawData)
        for jrawData = 1: length(rawData[irawData])
            temprawData = rawData[irawData][jrawData]
            if temprawData.code == code
                if temprawData.value > codeMax
                    codeMax = temprawData.value
                end
                if temprawData.value < codeMin
                    codeMin = temprawData.value
                end
            end
        end

    end
    println("The maximum value of code $(code) is $(codeMax), while the minimum value of code $(code) is $(codeMin).")
    return (codeMax, codeMin)
end
function randomIntervals(code::Int, rawData)::Array{Float64,1}
    (Max, Min) = min_max(code, rawData)
    τ_init = sample(Min:Max, 3, replace=false)
    return τ_init
end
function optimizeIteration(NIteration::Int)
    τ33_init = randomIntervals(33, rawData)
    τ34_init = randomIntervals(34, rawData)
    τ35_init = randomIntervals(35, rawData)
end
#(Max, Min) = min_max(35, rawData)
# JuMP.register(model, :f, nX, f, ∇f!)
# @NLobjective(model, Max, f(x...))
# # @load "x.jld2" x
# optimize!(model)
# xVal = fill(0.0, length(x))
# for i in 1:length(x)
#     xVal[i] = value(x[i])
# end
##statisticsIntervals(dataTransactions)
#@save "data_preprocessing.jld2" dataTransactions xVal
