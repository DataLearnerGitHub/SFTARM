using JLD2

FreqItemType = Tuple{String,Int}
FreqSetType = Set{FreqItemType}
FreqCountDict = Dict{FreqSetType,Float64}
function Apriori(result, minSupp)
    tableHead = result[1]

    numCols = length(tableHead)
    colNameToColIndex = Dict()
    for iCol = 1:numCols
        colNameToColIndex[tableHead[iCol]] = iCol
    end

    numTransactions = length(result[2])

    function filterFreqSet(counter, minSupp)
        newCounter = FreqCountDict()
        for (key, val) in counter
            if val >= minSupp
                newCounter[key] = val
            end
            for freqItem in key
                colName = freqItem[1]
                itemLevel = freqItem[2]
            end
        end
        newCounter
    end

    function find1FreqSet(result, minSupp)
        counter = FreqCountDict(
            Set([("bgLevel", 1)]) => 0.0,
            Set([("bgLevel", 2)]) => 0.0,
            Set([("bgLevel", 3)]) => 0.0,
        )
        for i = 2:numCols
            for j = 1:4
                counter[Set([(tableHead[i], j)])] = 0.0
            end
        end
        for transaction in result[2]
            for iCol = 1:numCols
                colName = tableHead[iCol]
                colVal = transaction[iCol]
                lowSet = Set([(colName, Int(floor(colVal)))])
                counter[lowSet] += floor(colVal) + 1 - colVal
                if ceil(colVal) == floor(colVal)
                    continue
                end
                highSet = Set([(colName, Int(floor(colVal)) + 1)])
                counter[highSet] += colVal - floor(colVal)
            end
        end
        for (key, val) in counter
            counter[key] = val / numTransactions
        end

        filterFreqSet(counter, minSupp)
    end

    function keyItemSet(key)
        retSet = Set()
        for item in key
            push!(retSet, item[1])
        end
        retSet
    end

    function findNextLevelFreqSet(result, prevCounter, minSupp)
        counter = FreqCountDict()
        for (key1, val1) in prevCounter
            expectedKeyLength = length(key1) + 1
            for (key2, val2) in prevCounter
                newKey = union(key1, key2)
                if length(newKey) != expectedKeyLength ||
                    length(keyItemSet(newKey)) != expectedKeyLength
                    continue
                end
                counter[newKey] = 0.0 #get(counter, newKey, 0.0) + val1 * val2
            end
        end
        #counter = filterFreqSet(counter, minSupp)

        for transaction in result[2]
            for (key, val) in counter
                Δval = 1.0
                for freqItem in key
                    colName = freqItem[1]
                    itemLevel = freqItem[2]
                    colIndex = colNameToColIndex[colName]
                    colVal = transaction[colIndex]
                    if itemLevel - 1 < colVal <= itemLevel
                        Δval *= colVal - itemLevel + 1
                    elseif itemLevel < colVal < itemLevel + 1
                        Δval *= itemLevel + 1 - colVal
                    else
                        Δval = 0.0
                    end
                end

                counter[key] = val + Δval
            end
        end
        for (key, val) in counter
            counter[key] = val / numTransactions
        end

        filterFreqSet(counter, minSupp)
    end

    prevCounter = find1FreqSet(result, minSupp)
    freqSetList = [prevCounter]
    println("analyzing level 2")
    fileNamePrefix = "freqItemSetLevel"
    outputFileName = fileNamePrefix * string(2)
    counter = Dict()
    try
        @load outputFileName counter
    catch
        counter = findNextLevelFreqSet(result, prevCounter, minSupp)
        @save outputFileName counter
    end
    k = 3
    while length(counter) > 0
        push!(freqSetList, counter)
        println("analyzing level " * string(k))
        prevCounter = counter
        outputFileName = fileNamePrefix * string(k)
        try
            @load outputFileName counter
        catch
            counter = findNextLevelFreqSet(result, prevCounter, minSupp)
            @save outputFileName counter
        end

        @save outputFileName freqSetList
        k += 1
    end

    freqSetList
end
function generate_TARules(freqSetList, minConf)
    #println("--------generate_TARules---------")
    TARules = []
    for i = length(freqSetList):-1:2
        #println("i=",i)
        for (key, val) in freqSetList[i]
            for freqItem in key
                antecedent = setdiff(key, Set([freqItem]))
                consequent = freqItem
                #println(antecedent, ",", consequent)
                support_of_antecedent = freqSetList[i-1][antecedent]
                Confidence_current = val / support_of_antecedent
                if Confidence_current >= minConf
                    push!(TARules,
                        ("Confidence_current=",
                        Confidence_current,
                        "  antecedent=",
                        antecedent,
                        "  consequent=",
                        consequent)
                    )
                end
            end
        end
    end
    TARules
end
@load "transactions_fuzzy.jld2" result
freqSetList = Apriori(result, 0.3)
TARules = generate_TARules(freqSetList, 0.6)
#@save "003.jld2" freqSetList
@save "TARules_all.jld2" TARules
#@load "TARules.jld2" TARules
