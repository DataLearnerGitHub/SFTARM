using JLD2
include("aprioriDerivative.jl")

#adjustParams functions
include("data_preprocessing_paramsCited.jl")
include("generateTransactions_timeParameters_params.jl")
function generate_TARules(maxIter,comparisonFilteredOutputRules,freqSetList, minSupp, minConf)
    count_outputed_rules = 0
    AvgSupport = 0.0
    AvgConfidence = 0.0
    AvgLift = 0.0
    Rules = []
    for i = length(freqSetList):-1:5
        for (key, val) in freqSetList[i]
            consequent = []
            for freqItem in key
                if freqItem[1] == "bgLevel" || freqItem[1] == "prevBgLevel" || freqItem[1] == "DcurrBgLevel"|| freqItem[1] == "DprevBgLevel"
                    push!(consequent, freqItem)
                end
            end
            if length(consequent) == 0
                continue
            end
            numConsequent = length(consequent)
            antecedent = setdiff(key, consequent)
            support_of_antecedent = freqSetList[i-numConsequent][antecedent]
            support_of_consequent = freqSetList[numConsequent][Set{Tuple{String,Int64}}(consequent)]
            Confidence_current = val / support_of_antecedent
            Lift_current = val / support_of_consequent
            if Confidence_current >= minConf
                count_outputed_rules = count_outputed_rules + 1
                AvgSupport = AvgSupport + val
                AvgConfidence = AvgConfidence + Confidence_current
                AvgLift = AvgLift + Lift_current
                push!(Rules, (count_outputed_rules, val, Confidence_current, Lift_current, antecedent, consequent))

            end
        end
    end
    @save "Results/RULES_$(maxIter)_$(minSupp)_$(minConf).jld2" Rules
    if count_outputed_rules == 0
        AvgSupport = 0.0
        AvgConfidence = 0.0
        AvgLift = 0.0
    else
        AvgSupport = AvgSupport / count_outputed_rules
        AvgConfidence = AvgConfidence / count_outputed_rules
        AvgLift = AvgLift / count_outputed_rules
    end
    println(comparisonFilteredOutputRules, "outputRules: count_outputed_rules=$count_outputed_rules, AvgSupport = $AvgSupport, AvgConfidence = $AvgConfidence, AvgLift = $AvgLift")
    println("outputRules: count_outputed_rules=$count_outputed_rules, AvgSupport = $AvgSupport, AvgConfidence = $AvgConfidence, AvgLift = $AvgLift")
    count_outputed_rules
end

# Further filtering Rules
function filterRules(maxIter,comparisonFilteredOutputRules, minSupp, minConf)
    NumberOfFilteredRules = 0
    AvgSupport = 0.0
    AvgConfidence = 0.0
    AvgLift = 0.0
    @load "Results/RULES_$(maxIter)_$(minSupp)_$(minConf).jld2" Rules
    #FilteredOutputRules = open(path*"FilteredOutputRules_$(minSupp)_$(minConf).txt", "w")
    # println(
    #     FilteredOutputRules,
    #     "Order_outputed_rules, Support, Confidence, Lift, Rules",
    # )
    FilteredRules = []
    for IRules = 1:length(Rules)
        itemsWith04 = []
        for item in Rules[IRules][5]
            if item[2] == 4 || item[2] == 0
                push!(itemsWith04, item)
            end
        end
        if length(Rules[IRules][5]) == length(itemsWith04)
            continue
        end
        consequent = Rules[IRules][6]
        if consequent == Any[("bgLevel", 2)] ||
           consequent == Any[("prevBgLevel", 2)] ||
           consequent == Any[("bgLevel", 2), ("prevBgLevel", 2)] ||
           consequent == Any[("prevBgLevel", 2), ("bgLevel", 2)]
            continue
        end
        push!(FilteredRules, Rules[IRules])
        NumberOfFilteredRules = NumberOfFilteredRules + 1
        AvgSupport = AvgSupport + Rules[IRules][2]
        AvgConfidence = AvgConfidence + Rules[IRules][3]
        AvgLift = AvgLift + Rules[IRules][4]
        # println(
        #     FilteredOutputRules,
        #     "$(Rules[IRules][1]):: $(Rules[IRules][2]), $(Rules[IRules][3]), $(Rules[IRules][4]), $(Rules[IRules][5]) ==> $(Rules[IRules][6])",
        # )
    end
    #close(FilteredOutputRules)
    if NumberOfFilteredRules == 0
        AvgSupport = 0.0
        AvgConfidence = 0.0
        AvgLift = 0.0
    else
        AvgSupport = AvgSupport / NumberOfFilteredRules
        AvgConfidence = AvgConfidence / NumberOfFilteredRules
        AvgLift = AvgLift / NumberOfFilteredRules
    end
    println(comparisonFilteredOutputRules, "FilteredRules: NumberOfFilteredRules=$NumberOfFilteredRules, AvgSupport = $AvgSupport, AvgConfidence = $AvgConfidence, AvgLift = $AvgLift")
    println("FilteredRules: NumberOfFilteredRules=$NumberOfFilteredRules, AvgSupport = $AvgSupport, AvgConfidence = $AvgConfidence, AvgLift = $AvgLift")
    NumberOfFilteredRules
end

minSupp = 0.1
minConf = 0.2
#println("111111111")
OutputRules_adjustParam = open("Results/OutputRules_adjustParams.txt", "w")
for maxIter = 1:3
    println("----------------------------maxIter=$(maxIter)-------------------------------")
    println(OutputRules_adjustParam, "--------------------------------maxIter=$(maxIter)--------------------------------")
    adjustParams_dataPreprocessing(maxIter)
    adjustParams_generateTransactions(maxIter)
    @load "Results/Transactions_timeParameters_$(maxIter).jld2" result
    val,t=@timed begin
    freqSetList = Apriori(result, minSupp)
    end
    NumberOfRules = generate_TARules(maxIter, OutputRules_adjustParam, freqSetList, minSupp, minConf)
    NumberOfFilteredRules = filterRules(maxIter, OutputRules_adjustParam, minSupp, minConf)
    println("maxIter = $maxIter, ExecutingTime = $t, filteredRatio = $(NumberOfFilteredRules/NumberOfRules)")
    println(OutputRules_adjustParam, "maxIter = $maxIter, ExecutingTime = $t, filteredRatio = $(NumberOfFilteredRules/NumberOfRules), NumberOfRules = $NumberOfRules, NumberOfFilteredRules = $NumberOfFilteredRules")
end
close(OutputRules_adjustParam)
